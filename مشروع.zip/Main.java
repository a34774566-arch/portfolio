import java.util.Scanner;

// ============================================
// Main Class - القائمة الرئيسية
// ============================================
public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        Library library = new Library();

        // ── بيانات تجريبية ──────────────────
        library.addBook(new Book("Clean Code",       "Robert Martin", "001"));
        library.addBook(new Book("The Great Gatsby", "F. Fitzgerald", "002"));
        library.addBook(new Book("Java Basics",      "Herbert Schildt","003"));

        library.addMember(new Member("Ali Hassan",  "M01", "Premium"));
        library.addMember(new Member("Nour Khalil", "M02", "Standard"));

        // ── القائمة ─────────────────────────
        boolean running = true;

        while (running) {
            System.out.println("\n==============================");
            System.out.println("   Library Management System  ");
            System.out.println("==============================");
            System.out.println("1. Show All Books");
            System.out.println("2. Show All Members");
            System.out.println("3. Borrow a Book");
            System.out.println("4. Return a Book");
            System.out.println("5. Search for a Book");
            System.out.println("0. Exit");
            System.out.print("Choose: ");

            // Exception Handling للـ input
            try {
                int choice = Integer.parseInt(scanner.nextLine());

                switch (choice) {
                    case 1 -> library.showAllBooks();
                    case 2 -> library.showAllMembers();
                    case 3 -> {
                        System.out.print("Enter ISBN to borrow: ");
                        library.borrowBook(scanner.nextLine());
                    }
                    case 4 -> {
                        System.out.print("Enter ISBN to return: ");
                        library.returnBook(scanner.nextLine());
                    }
                    case 5 -> {
                        System.out.print("Enter keyword: ");
                        library.searchBook(scanner.nextLine());
                    }
                    case 0 -> {
                        System.out.println("Goodbye!");
                        running = false;
                    }
                    default -> System.out.println("Invalid choice, try again.");
                }

            } catch (NumberFormatException e) {
                // Exception Handling: إذا المستخدم كتب حرف بدل رقم
                System.out.println("Please enter a number!");
            }
        }

        scanner.close();
    }
}
