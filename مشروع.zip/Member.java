// ============================================
// Inheritance: Member ترث من Person
// ============================================
public class Member extends Person {

    private String memberType; // "Standard" أو "Premium"

    public Member(String name, String id, String memberType) {
        super(name, id); // استدعاء constructor الـ Person
        this.memberType = memberType;
    }

    public String getMemberType() { return memberType; }

    // Polymorphism: تنفيذ showInfo بطريقة Member
    @Override
    public void showInfo() {
        System.out.println("--- Member Info ---");
        System.out.println("Name: " + getName());
        System.out.println("ID  : " + getId());
        System.out.println("Type: " + memberType);
    }
}
