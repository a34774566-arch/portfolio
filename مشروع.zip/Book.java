// ============================================
// Book Class (كلاس الكتاب)
// ============================================
public class Book {

    // Encapsulation: المتغيرات private
    private String title;
    private String author;
    private String isbn;
    private boolean available;

    public Book(String title, String author, String isbn) {
        this.title     = title;
        this.author    = author;
        this.isbn      = isbn;
        this.available = true; // متاح عند الإضافة
    }

    // Getters
    public String  getTitle()     { return title;     }
    public String  getAuthor()    { return author;    }
    public String  getIsbn()      { return isbn;      }
    public boolean isAvailable()  { return available; }

    // Borrow & Return
    public void borrowBook() { available = false; }
    public void returnBook() { available = true;  }

    public void showInfo() {
        System.out.println("Title : " + title);
        System.out.println("Author: " + author);
        System.out.println("ISBN  : " + isbn);
        System.out.println("Status: " + (available ? "Available" : "Borrowed"));
    }
}
