import java.util.ArrayList;

// ============================================
// Library Class (كلاس المكتبة - القلب)
// ============================================
public class Library {

    // ArrayList لتخزين الكتب والأعضاء
    private ArrayList<Book>   books   = new ArrayList<>();
    private ArrayList<Member> members = new ArrayList<>();

    // ── إضافة كتاب ──────────────────────────
    public void addBook(Book book) {
        books.add(book);
        System.out.println("Book added: " + book.getTitle());
    }

    // ── إضافة عضو ───────────────────────────
    public void addMember(Member member) {
        members.add(member);
        System.out.println("Member added: " + member.getName());
    }

    // ── عرض جميع الكتب ──────────────────────
    public void showAllBooks() {
        System.out.println("\n===== All Books =====");
        if (books.isEmpty()) {
            System.out.println("No books found.");
            return;
        }
        for (int i = 0; i < books.size(); i++) {
            System.out.println("\n[" + (i + 1) + "]");
            books.get(i).showInfo();
        }
    }

    // ── عرض جميع الأعضاء ────────────────────
    public void showAllMembers() {
        System.out.println("\n===== All Members =====");
        if (members.isEmpty()) {
            System.out.println("No members found.");
            return;
        }
        for (Member m : members) {
            System.out.println();
            m.showInfo();
        }
    }

    // ── استعارة كتاب ────────────────────────
    public void borrowBook(String isbn) {
        for (Book b : books) {
            if (b.getIsbn().equals(isbn)) {
                if (b.isAvailable()) {
                    b.borrowBook();
                    System.out.println("You borrowed: " + b.getTitle());
                } else {
                    System.out.println("Sorry, this book is not available.");
                }
                return;
            }
        }
        System.out.println("Book not found.");
    }

    // ── إرجاع كتاب ──────────────────────────
    public void returnBook(String isbn) {
        for (Book b : books) {
            if (b.getIsbn().equals(isbn)) {
                b.returnBook();
                System.out.println("Book returned: " + b.getTitle());
                return;
            }
        }
        System.out.println("Book not found.");
    }

    // ── البحث عن كتاب ───────────────────────
    public void searchBook(String keyword) {
        System.out.println("\n===== Search Results =====");
        boolean found = false;
        for (Book b : books) {
            if (b.getTitle().toLowerCase().contains(keyword.toLowerCase())) {
                b.showInfo();
                System.out.println();
                found = true;
            }
        }
        if (!found) System.out.println("No books match: " + keyword);
    }
}
