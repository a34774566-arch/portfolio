// ============================================
// Abstract Class (الكلاس الأساسي المجرد)
// ============================================
public abstract class Person {

    // Encapsulation: المتغيرات private
    private String name;
    private String id;

    // Constructor
    public Person(String name, String id) {
        this.name = name;
        this.id   = id;
    }

    // Getters & Setters
    public String getName() { return name; }
    public String getId()   { return id;   }

    // Abstract method: كل subclass لازم تعملها بطريقتها
    public abstract void showInfo();
}
