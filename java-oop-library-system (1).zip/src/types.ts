export interface BookState {
  id: string;
  title: string;
  author: string;
  type: "Physical" | "Digital";
  isBorrowed: boolean;
  shelfLocation?: string;
  fileSizeMB?: number;
  downloadUrl?: string;
}

export interface ConsoleLog {
  id: string;
  message: string;
  type: "info" | "success" | "warning" | "error" | "codeLine";
  timestamp: string;
}

export interface QuizQuestion {
  id: number;
  question: string;
  questionAr: string;
  options: string[];
  optionsAr: string[];
  correctAnswer: number;
  explanation: string;
  explanationAr: string;
  oopConcept: string;
}

export const OOP_QUIZ: QuizQuestion[] = [
  {
    id: 1,
    question: "Which OOP concept is represented by setting fields to 'private' and accessing them via getters and setters?",
    questionAr: "أي مفاهيم الكائنات الموجهة (OOP) يتمثل في جعل المتغيرات private والوصول إليها عبر getters/setters؟",
    options: ["Inheritance", "Polymorphism", "Encapsulation", "Abstraction"],
    optionsAr: ["الوراثة (Inheritance)", "تعدد الأشكال (Polymorphism)", "التغليف (Encapsulation)", "التجريد (Abstraction)"],
    correctAnswer: 2,
    explanation: "Encapsulation hides the internal state of an object and restricts direct access, exposing it only through public methods (getters and setters).",
    explanationAr: "مبدأ التغليف (Encapsulation) يهدف لإخفاء الحالة الداخلية للكائن ومنع الوصول المباشر، متيحاً إياها فقط من خلال دوال عامة.",
    oopConcept: "Encapsulation (التغليف)"
  },
  {
    id: 2,
    question: "If 'PhysicalBook' and 'EBook' both inherit from the abstract class 'Book' and provide different implementations of 'calculateLateFee()', which concept is this?",
    questionAr: "إذا كان كل من 'PhysicalBook' و 'EBook' يرثان من الفئة المجردة 'Book' ويقدمان تطبيقاً مختلفاً لدالة 'calculateLateFee()'، فما هذا المفهوم؟",
    options: ["Encapsulation", "Polymorphism / Method Overriding", "Multiple Inheritance", "Interface Implementation"],
    optionsAr: ["التغليف (Encapsulation)", "تعدد الأشكال / إعادة الكتابة (Polymorphism / Overriding)", "الوراثة المتعددة", "تطبيق الواجهات"],
    correctAnswer: 1,
    explanation: "This is Polymorphism (specifically dynamic method overriding), where child classes provide their own unique implementation of a method defined in the parent class.",
    explanationAr: "هذا هو تعدد الأشكال (Polymorphism) وبالأخص الـ Overriding، حيث تقدم الفئات الابنة تطبيقاً خاصاً بها لدالة معرّفة في الفئة الأب.",
    oopConcept: "Polymorphism (تعدد الأشكال)"
  },
  {
    id: 3,
    question: "What keyword is used in Java to run a parent class constructor inside a subclass constructor?",
    questionAr: "ما هي الكلمة المفتاحية المستخدمة في لغة جافا لاستدعاء مشيّد الفئة الأب (Constructor) داخل مشيّد الفئة الابنة؟",
    options: ["this", "parent", "super", "extends"],
    optionsAr: ["this", "parent", "super", "extends"],
    correctAnswer: 2,
    explanation: "The 'super' keyword is used in subclasses to invoke constructors, methods, or fields of the immediate parent (superclass).",
    explanationAr: "تُستخدم الكلمة المفتاحية 'super' داخل الفئات الفرعية لاستدعاء مشيدات، دوال أو متغيرات الفئة الأصلية الأب مباشرة.",
    oopConcept: "Inheritance (الوراثة)"
  },
  {
    id: 4,
    question: "Which collection type would you use for a library catalog that must grow or shrink dynamically as books are added or removed?",
    questionAr: "أي نوع من المجموعات (Collections) ستستخدمه لتخزين فهرس المكتبة الذي يحتاج للنمو والتقلص ديناميكياً مع إضافة أو حذف الكتب؟",
    options: ["Standard Array [ ]", "ArrayList", "String", "boolean"],
    optionsAr: ["المصفوفة العادية Float/Double Array", "مصفوفة القائمة المرنة ArrayList", "النصوص String", "القيم المنطقية boolean"],
    correctAnswer: 1,
    explanation: "ArrayList is a resizable-array implementation in Java that allows dynamic addition and removal of elements, unlike fixed-size arrays.",
    explanationAr: "مصفوفة الـ ArrayList هي بنية تخزين مرنة وقابلة للتمدد تتيح إضافة وحذف العناصر ديناميكياً بخلاف المصفوفات الثابتة الحجم.",
    oopConcept: "Arrays & ArrayLists (المصوفات المرنة)"
  },
  {
    id: 5,
    question: "What happens when you declare a class 'abstract' in Java?",
    questionAr: "ماذا يترتب على تعريف فئة بكونها 'abstract' (عامة مجردة) في لغة جافا؟",
    options: [
      "You cannot instantiate it directly using the 'new' keyword.",
      "All of its methods must have no body.",
      "It cannot have any subclasses.",
      "It cannot contain any fields or getters."
    ],
    optionsAr: [
      "لا يمكنك إنشاء كائنات (Objects) منها مباشرة باستخدام كلمة new.",
      "يجب أن تكون جميع دوالها بدون متن/أكواد.",
      "لا يمكنها امتلاك أي فئات ابنة وارثة.",
      "لا يمكنها احتواء أي حقول أو دوال جلب."
    ],
    correctAnswer: 0,
    explanation: "An abstract class cannot be instantiated directly. It serves as a blueprint for other classes to inherit from and implement abstract behaviors.",
    explanationAr: "الفئات المجردة (Abstract Classes) لا يمكن إنشاء كائنات منها مباشرة، وتُستخدم كقاعدة عامة ترث منها الفئات الفرعية وتطبق دوالها.",
    oopConcept: "Abstract Classes (الفئات المجردة)"
  }
];
