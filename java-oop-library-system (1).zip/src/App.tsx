import React, { useState } from "react";
import { BookState, ConsoleLog } from "./types";
import ConsoleStream from "./components/ConsoleStream";
import JavaCodeExplorer from "./components/JavaCodeExplorer";
import InteractiveTutor from "./components/InteractiveTutor";
import VisualLibraryControl from "./components/VisualLibraryControl";
import OopQuiz from "./components/OopQuiz";
import { 
  FolderGit2, GraduationCap, Code, Compass, HelpCircle, 
  Github, Layers, ShieldCheck, Download, Sparkles, BookMarked,
  Network, Eye, RefreshCw
} from "lucide-react";

const DEFAULT_BOOKS: BookState[] = [
  { id: "B001", title: "Clean Code: A Handbook of Agile Software Craftsmanship", author: "Robert C. Martin", type: "Physical", isBorrowed: false, shelfLocation: "Shelf A-12" },
  { id: "B002", title: "Effective Java (3rd Edition)", author: "Joshua Bloch", type: "Digital", isBorrowed: false, fileSizeMB: 12.4, downloadUrl: "https://example.com/effective-java.pdf" },
  { id: "B003", title: "Design Patterns: Elements of Reusable Object-Oriented Software", author: "Erich Gamma", type: "Physical", isBorrowed: true, shelfLocation: "Shelf B-04" },
  { id: "B004", title: "Java: The Complete Reference", author: "Herbert Schildt", type: "Digital", isBorrowed: false, fileSizeMB: 24.8, downloadUrl: "https://example.com/java-ref.pdf" },
  { id: "B005", title: "البرمجة الشيئية كائنية التوجه بلغة جافا", author: "د. أسعد ذياب الحسين", type: "Physical", isBorrowed: false, shelfLocation: "Shelf C-01" },
  { id: "B006", title: "بنية البيانات والخوارزميات في جافا", author: "أ.د. خالد فوزي الغامدي", type: "Digital", isBorrowed: false, fileSizeMB: 18.5, downloadUrl: "https://example.com/arabic-data-structures-java.pdf" },
  { id: "B007", title: "Introduction to Algorithms (CLRS)", author: "Thomas H. Cormen", type: "Physical", isBorrowed: true, shelfLocation: "Shelf B-09" },
  { id: "B008", title: "Cracking the Coding Interview", author: "Gayle Laakmann McDowell", type: "Digital", isBorrowed: false, fileSizeMB: 15.2, downloadUrl: "https://example.com/ctci.pdf" }
];

export default function App() {
  // Simulator states
  const [books, setBooks] = useState<BookState[]>(DEFAULT_BOOKS);
  const [logs, setLogs] = useState<ConsoleLog[]>([
    { id: "l1", message: "[System] Compiling OOP Library simulation files under 'package library;' ...", type: "info", timestamp: "07:54:01" },
    { id: "l2", message: "javac library/*.java  (Build Succeeded - 0 errors, 0 warnings)", type: "success", timestamp: "07:54:02" },
    { id: "l3", message: "java library.Main (Booting virtual JVM runtime engine with Polymorphism)", type: "info", timestamp: "07:54:03" },
    { id: "l4", message: "System: Added 'Clean Code...' to library catalogs.", type: "info", timestamp: "07:54:03" },
    { id: "l5", message: "System: Added 'Effective Java...' to library catalogs.", type: "info", timestamp: "07:54:03" },
    { id: "l6", message: "System: Added 'Design Patterns...' to library catalogs.", type: "info", timestamp: "07:54:03" },
    { id: "l7", message: "System: Added 'Java: The Complete Reference...' to library catalogs.", type: "info", timestamp: "07:54:03" },
    { id: "l8", message: "System: Added 'البرمجة الشيئية كائنية التوجه بلغة جافا...' to library catalogs.", type: "info", timestamp: "07:54:04" },
    { id: "l9", message: "System: Added 'بنية البيانات والخوارزميات في جافا...' to library catalogs.", type: "info", timestamp: "07:54:04" }
  ]);
  const [activeTab, setActiveTab] = useState<"simulator" | "code" | "tutor" | "quiz">("simulator");
  const [activeJavaFile, setActiveJavaFile] = useState("Main.java");

  // Helper logger
  const addLog = (message: string, type: ConsoleLog["type"]) => {
    const timeStr = new Date().toLocaleTimeString('en-US', { hour12: false });
    const newLog: ConsoleLog = {
      id: "log_" + Date.now() + "_" + Math.random().toString(36).substr(2, 4),
      message,
      type,
      timestamp: timeStr
    };
    setLogs(prev => [...prev, newLog]);
  };

  // Synchronized Simulation interactions
  const handleAddBook = (newBook: BookState, javaStatement: string) => {
    setBooks(prev => [...prev, newBook]);
    addLog(`// Java instantiation for new book:`, "codeLine");
    addLog(javaStatement, "codeLine");
    addLog(`System: Added '${newBook.title}' to library catalogs. [Object references created]`, "success");
    setActiveJavaFile("Library.java");
  };

  const handleBorrow = (id: string) => {
    const targetBook = books.find(b => b.id === id);
    if (!targetBook) {
      addLog(`myLibrary.borrowBook("${id}");`, "codeLine");
      addLog(`library.BookNotFoundException: Exception: Book ID '${id}' was not found in the Library inventory!`, "error");
      setActiveJavaFile("BookNotFoundException.java");
      return;
    }

    addLog(`myLibrary.borrowBook("${id}");  // Title: ${targetBook.title}`, "codeLine");
    setActiveJavaFile("Library.java");

    if (targetBook.isBorrowed) {
      // Simulate throwing custom BookAlreadyBorrowedException
      addLog(`library.BookAlreadyBorrowedException: Error: Book '${targetBook.title}' is already borrowed!`, "error");
      addLog(`  at library.Book.borrowBook(Book.java:71)`, "error");
      addLog(`  at library.Library.borrowBook(Library.java:44)`, "error");
      addLog(`  at library.Main.main(Main.java:42)`, "error");
      addLog(`[Try-Catch Block Actioned]: Custom Exception was successfully caught in Main.java try-catch.`, "warning");
      setActiveJavaFile("BookAlreadyBorrowedException.java");
    } else {
      // Success borrowing
      setBooks(prev => prev.map(b => b.id === id ? { ...b, isBorrowed: true } : b));
      addLog(`System: Borrowed successfully! Enjoy reading '${targetBook.title}'. Status set to borrowed = true.`, "success");
      setActiveJavaFile("Book.java");
    }
  };

  const handleReturn = (id: string) => {
    const targetBook = books.find(b => b.id === id);
    if (!targetBook) return;

    addLog(`myLibrary.returnBook("${id}");`, "codeLine");
    setBooks(prev => prev.map(b => b.id === id ? { ...b, isBorrowed: false } : b));
    addLog(`System: Returned successfully! '${targetBook.title}' is now available. State modified.`, "success");
    setActiveJavaFile("Library.java");
  };

  const handleCalcFee = (id: string, days: number) => {
    const targetBook = books.find(b => b.id === id);
    if (!targetBook) return;

    const rate = targetBook.type === "Physical" ? 2.50 : 0.50;
    const calculated = days * rate;

    addLog(`myLibrary.findBookById("${id}").calculateLateFee(${days});`, "codeLine");
    addLog(`Polymorphic fee trigger on ${targetBook.type === "Physical" ? "PhysicalBook" : "EBook"}: $${calculated.toFixed(2)}`, "info");
    setActiveJavaFile("Book.java");
  };

  const handleClearLogs = () => {
    setLogs([]);
  };

  const handleResetSimulator = () => {
    setBooks(DEFAULT_BOOKS);
    setLogs([
      { id: "r1", message: "[System] Resetting virtual JVM runtime engine state...", type: "info", timestamp: "Reset" },
      { id: "r2", message: "Library items restored to university prepopulated values.", type: "success", timestamp: "Reset" }
    ]);
    addLog(`Library myLibrary = new Library(); // Fresh instance.`, "codeLine");
  };

  // Structural Concept Quick-Shortcuts
  const OOP_SHORTCUTS = [
    { name: "Classes & Objects", file: "Book.java", desc: "Instantiation and parameters", arName: "الفئات والكائنات" },
    { name: "Encapsulation", file: "Book.java", desc: "Private fields & getters/setters", arName: "التغليف وكبسلة البيانات" },
    { name: "Inheritance (الوراثة)", file: "PhysicalBook.java", desc: "extends Book subclassing", arName: "الوراثة (Extends)" },
    { name: "Polymorphism", file: "EBook.java", desc: "Dynamic Late Fee Override", arName: "تعدد الأشكال (Overriding)" },
    { name: "Abstract Class", file: "Book.java", desc: "Abstract methods definitions", arName: "الفئات المجردة (Abstract)" },
    { name: "ArrayLists", file: "Library.java", desc: "Dynamic collection tracking", arName: "مجموعات ArrayList" },
    { name: "Exceptions handling", file: "Main.java", desc: "Try-catch throw statements", arName: "معالجة الاستثناءات ومصلحيها" }
  ];

  return (
    <div className="h-screen w-full bg-slate-100 text-slate-900 flex flex-col md:flex-row overflow-hidden font-sans">
      
      {/* 1. Left Sidebar (Professional Polish Dark Navigation Column) */}
      <aside className="w-full md:w-64 bg-slate-900 text-white flex flex-col shrink-0 border-b md:border-b-0 md:border-r border-slate-800">
        
        {/* Sidebar Header Brand */}
        <div className="p-5 flex items-center justify-between md:justify-start gap-3 border-b border-slate-800 bg-slate-950">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-blue-600 rounded flex items-center justify-center font-bold text-white shadow font-mono">L</div>
            <div className="flex flex-col">
              <span className="text-md font-bold text-white tracking-tight leading-none">LibriSys Pro</span>
              <span className="text-[10px] text-slate-400 font-semibold font-mono mt-1">Java OOP Engine</span>
            </div>
          </div>
          
          <span className="md:hidden bg-indigo-500/20 text-indigo-300 text-[9px] font-bold px-2 py-0.5 rounded border border-indigo-400/40">
            JVM active
          </span>
        </div>

        {/* Sidebar Navigation */}
        <nav className="p-4 space-y-1.5 flex-1 overflow-y-auto">
          <div className="text-[10px] font-bold text-slate-500 uppercase tracking-widest px-2 pb-1.5 select-none hidden md:block">
            Main Navigation
          </div>
          
          <button
            onClick={() => setActiveTab("simulator")}
            className={`w-full rounded-lg px-3.5 py-2.5 flex items-center gap-3 text-xs font-medium cursor-pointer transition-all ${
              activeTab === "simulator"
                ? "bg-blue-600 text-white font-semibold shadow-md"
                : "text-slate-400 hover:text-white hover:bg-slate-800"
            }`}
          >
            <Compass className="w-4 h-4 text-blue-400 shrink-0" />
            <span className="text-right flex-1 font-sans">لوحة المحاكاة (Simulator)</span>
          </button>

          <button
            onClick={() => {
              setActiveTab("code");
              setActiveJavaFile("Main.java");
            }}
            className={`w-full rounded-lg px-3.5 py-2.5 flex items-center gap-3 text-xs font-medium cursor-pointer transition-all ${
              activeTab === "code"
                ? "bg-blue-600 text-white font-semibold shadow-md"
                : "text-slate-400 hover:text-white hover:bg-slate-800"
            }`}
          >
            <Code className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="text-right flex-1 font-sans">أكواد السورس جافا (Source)</span>
          </button>

          <button
            onClick={() => setActiveTab("tutor")}
            className={`w-full rounded-lg px-3.5 py-2.5 flex items-center gap-3 text-xs font-medium cursor-pointer transition-all relative ${
              activeTab === "tutor"
                ? "bg-blue-600 text-white font-semibold shadow-md"
                : "text-slate-400 hover:text-white hover:bg-slate-800"
            }`}
          >
            <GraduationCap className="w-4 h-4 text-indigo-400 shrink-0" />
            <span className="text-right flex-1 font-sans">المعلّم المساعد (AI Tutor)</span>
            <span className="absolute top-2.5 right-2 w-2 h-2 bg-indigo-400 rounded-full animate-pulse"></span>
          </button>

          <button
            onClick={() => setActiveTab("quiz")}
            className={`w-full rounded-lg px-3.5 py-2.5 flex items-center gap-3 text-xs font-medium cursor-pointer transition-all ${
              activeTab === "quiz"
                ? "bg-blue-600 text-white font-semibold shadow-md"
                : "text-slate-400 hover:text-white hover:bg-slate-800"
            }`}
          >
            <HelpCircle className="w-4 h-4 text-amber-400 shrink-0" />
            <span className="text-right flex-1 font-sans">اختبِر مفاهيمك (OOP Quiz)</span>
          </button>

          {/* Core Concept Tracer */}
          <div className="pt-5 pb-2 px-2 text-[10px] font-bold text-slate-500 uppercase tracking-widest select-none hidden md:block">
            OOP Concept Tracer (الفئات والملفات)
          </div>

          <div className="hidden md:flex flex-col gap-1 px-1.5 space-y-0.5 max-h-56 overflow-y-auto">
            {OOP_SHORTCUTS.map((sc, idx) => {
              const matchesFile = activeJavaFile === sc.file;
              return (
                <button
                  key={idx}
                  onClick={() => {
                    setActiveJavaFile(sc.file);
                    setActiveTab("code");
                  }}
                  className={`w-full text-right py-1.5 px-2.5 rounded text-[11px] font-mono transition-colors flex items-center justify-between gap-1.5 ${
                    matchesFile && activeTab === "code"
                      ? "bg-emerald-950/40 text-emerald-400 border border-emerald-800/50"
                      : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/40"
                  }`}
                >
                  <span className="text-[10px] opacity-60 font-sans tracking-wide truncate">{sc.name}</span>
                  <span className="font-semibold shrink-0">{sc.file}</span>
                </button>
              );
            })}
          </div>

        </nav>

        {/* Sidebar Footer Profile */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/40 hidden md:block">
          <div className="flex items-center gap-3 px-2">
            <div className="w-8 h-8 bg-blue-500/10 text-blue-400 rounded-full border border-blue-500/20 flex items-center justify-center font-bold text-xs">
              CS
            </div>
            <div className="flex flex-col">
              <span className="text-xs font-semibold text-slate-200">البيئة البرمجية جافا</span>
              <span className="text-[9px] text-slate-400 uppercase tracking-wider font-mono">Local JVM Simulator</span>
            </div>
          </div>
        </div>

      </aside>

      {/* 2. Main Workspace (Right Side) */}
      <main className="flex-1 flex flex-col overflow-hidden min-w-0">
        
        {/* Dynamic Professional Header */}
        <header className="h-16 bg-white border-b border-slate-200 px-6 flex items-center justify-between shrink-0 shadow-xs z-10">
          <div className="flex items-center gap-3">
            <h1 className="text-sm md:text-md font-bold text-slate-800 tracking-tight font-sans">
              {activeTab === "simulator" && "لوحة تحكم المكتبة التفاعلية (JVM Virtual Engine)"}
              {activeTab === "code" && "مستكشف الأكواد المصدرية جافا (Source Engine Explorer)"}
              {activeTab === "tutor" && "المساعد الأكاديمي لشرح مفاهيم الكائنات الموجهة (AI CS Professor)"}
              {activeTab === "quiz" && "اختبار المفاهيم البرمجية (Java OOP Self-Evaluation)"}
            </h1>
            <span className="bg-blue-50 text-blue-600 text-[10px] font-bold px-2.5 py-0.5 rounded-full border border-blue-200 uppercase tracking-wide">
              Active Session
            </span>
          </div>
          
          <div className="flex items-center gap-4">
            <span className="text-xs text-slate-500 font-mono hidden sm:inline">SDK Compatibility: Java SE 17+</span>
            <div className="flex items-center gap-1.5 self-center">
              <span className="h-2 w-2 rounded-full bg-green-500 animate-pulse"></span>
              <span className="text-[11px] font-semibold text-slate-500 font-mono">Auto-Compile On</span>
            </div>
          </div>
        </header>

        {/* 3. Dynamic Interactive Metrics Panel (Real-time evaluation) */}
        <div className="bg-slate-50 p-6 border-b border-slate-200 shrink-0 shadow-inner">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            
            {/* Metric 1 */}
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs hover:border-blue-400 transition-all">
              <div className="text-slate-400 text-[9px] font-bold uppercase tracking-widest mb-1">إجمالي الكتل بالفهرس (Total Objects)</div>
              <div className="text-lg md:text-xl font-bold text-slate-800 font-mono">{books.length} Books</div>
              <p className="text-[10px] text-emerald-600 mt-1 font-medium font-sans">ArrayList dynamic list size</p>
            </div>

            {/* Metric 2 */}
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs hover:border-blue-400 transition-all">
              <div className="text-slate-400 text-[9px] font-bold uppercase tracking-widest mb-1">الكتب المستعارة في الذاكرة (Loans)</div>
              <div className="text-lg md:text-xl font-bold text-slate-800 font-mono">
                {books.filter(b => b.isBorrowed).length} / {books.length}
              </div>
              <p className="text-[10px] text-slate-400 mt-1 font-sans">Borrowed state flags active</p>
            </div>

            {/* Metric 3 */}
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs hover:border-rose-400 transition-all">
              <div className="text-slate-400 text-[9px] font-bold uppercase tracking-widest mb-1">الأخطاء المعالجة (Exceptions Caught)</div>
              <div className="text-lg md:text-xl font-bold text-rose-600 font-mono">
                {logs.filter(l => l.type === "error").length} Caught
              </div>
              <p className="text-[10px] text-rose-500/80 mt-1 font-sans font-medium">Auto try-catch handlers active</p>
            </div>

            {/* Metric 4 */}
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs hover:border-emerald-400 transition-all">
              <div className="text-slate-400 text-[9px] font-bold uppercase tracking-widest mb-1">غرامات التأخير التقريبية (Late Fines)</div>
              <div className="text-lg md:text-xl font-bold text-slate-900 font-mono">
                ${books.reduce((acc, b) => acc + (b.isBorrowed ? (b.type === "Physical" ? 12.50 : 2.50) : 0), 0).toFixed(2)}
              </div>
              <p className="text-[10px] text-slate-400 mt-1 font-sans">Dynamic Polymorphism calc</p>
            </div>

          </div>
        </div>

        {/* 4. Scrollable Tab Workspace */}
        <div className="flex-1 overflow-y-auto bg-slate-100 p-6 min-h-0">
          
          {activeTab === "simulator" && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start h-full">
              
              {/* Visual Control Desk - Left Side (7 Cols) */}
              <div className="lg:col-span-7 space-y-6">
                
                <VisualLibraryControl
                  books={books}
                  onAddBook={handleAddBook}
                  onBorrowBook={handleBorrow}
                  onReturnBook={handleReturn}
                  onCalculateFee={handleCalcFee}
                  onLog={addLog}
                  onSetActiveFile={setActiveJavaFile}
                />

                {/* JVM Live Terminal Stream */}
                <ConsoleStream 
                  logs={logs}
                  onClear={handleClearLogs}
                />

              </div>

              {/* Integrated IDE Previews - Right Side (5 Cols) */}
              <div className="lg:col-span-5 flex flex-col justify-between space-y-4 h-[640px]">
                
                <div className="flex-1 min-h-0 bg-[#1e293b] rounded-xl border border-slate-200 shadow overflow-hidden flex flex-col">
                  
                  <div className="bg-slate-900 px-3.5 py-2 flex items-center justify-between border-b border-slate-800 select-none">
                    <div className="flex items-center gap-1.5">
                      <Eye className="w-4 h-4 text-emerald-400" />
                      <span className="text-xs text-slate-300 font-bold font-mono">
                        Source Code Lens (استكشاف كود جافا)
                      </span>
                    </div>
                    <span className="text-[10px] font-mono text-indigo-400 font-bold bg-indigo-950/40 px-2 py-0.5 rounded">
                      {activeJavaFile}
                    </span>
                  </div>

                  <div className="flex-1 min-h-0">
                    <JavaCodeExplorer 
                      activeFileName={activeJavaFile}
                      setActiveFileName={setActiveJavaFile}
                    />
                  </div>

                </div>

                {/* JVM Reset Card */}
                <div className="bg-white border border-slate-200 rounded-xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-sm shrink-0">
                  <div className="text-right md:text-left">
                    <h4 className="text-xs font-bold text-slate-900 font-sans">هل تحتاج لإعادة تصفير المحاكات؟</h4>
                    <p className="text-[10px] text-slate-500 font-sans">مسح الـ Memory ArrayList وإعادة تحميل كتب المشروع المرجعية الأساسية.</p>
                  </div>
                  <button
                    onClick={handleResetSimulator}
                    className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-all cursor-pointer shadow shrink-0 self-stretch sm:self-auto text-center justify-center font-sans"
                  >
                    <RefreshCw className="w-3.5 h-3.5 animate-spin-reverse" />
                    <span>تصفير ومحاكاة جافا</span>
                  </button>
                </div>

              </div>

            </div>
          )}

          {activeTab === "code" && (
            <div className="h-[680px]">
              <JavaCodeExplorer 
                activeFileName={activeJavaFile}
                setActiveFileName={setActiveJavaFile}
              />
            </div>
          )}

          {activeTab === "tutor" && (
            <div className="max-w-4xl mx-auto h-full">
              <InteractiveTutor />
            </div>
          )}

          {activeTab === "quiz" && (
            <div className="max-w-3xl mx-auto h-full">
              <OopQuiz />
            </div>
          )}

        </div>

      </main>

    </div>
  );
}
