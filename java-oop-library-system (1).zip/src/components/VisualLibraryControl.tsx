import React, { useState } from "react";
import { BookState, ConsoleLog } from "../types";
import { 
  BookOpen, Plus, Search, CheckCircle, XCircle, AlertCircle, 
  HelpCircle, Calendar, Sparkles, AlertTriangle, CloudDownload, MapPin 
} from "lucide-react";

interface VisualLibraryControlProps {
  books: BookState[];
  onAddBook: (newBook: BookState, javaStatement: string) => void;
  onBorrowBook: (id: string) => void;
  onReturnBook: (id: string) => void;
  onCalculateFee: (id: string, days: number) => void;
  onLog: (msg: string, type: ConsoleLog["type"]) => void;
  onSetActiveFile: (name: string) => void;
}

export default function VisualLibraryControl({
  books,
  onAddBook,
  onBorrowBook,
  onReturnBook,
  onCalculateFee,
  onLog,
  onSetActiveFile
}: VisualLibraryControlProps) {
  // Add Book modal state
  const [showAddModal, setShowAddModal] = useState(false);
  const [newType, setNewType] = useState<"Physical" | "Digital">("Physical");
  const [newTitle, setNewTitle] = useState("");
  const [newAuthor, setNewAuthor] = useState("");
  const [newId, setNewId] = useState("");
  const [shelfLoc, setShelfLoc] = useState("Shelf C-10");
  const [fileSize, setFileSize] = useState(15.2);
  const [downUrl, setDownUrl] = useState("https://example.com/download-book.pdf");

  // Search ID
  const [searchId, setSearchId] = useState("");
  const [feeDays, setFeeDays] = useState(5);

  const handleSubmitAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newId.trim() || !newTitle.trim() || !newAuthor.trim()) {
      alert("Please fill in Book ID, Title, and Author.");
      return;
    }

    // Check if ID already exists
    if (books.some(b => b.id.toLowerCase() === newId.trim().toLowerCase())) {
      onLog(`Compilation Attempt Failed: Duplicate Book ID '${newId}' in database catalog.`, "error");
      return;
    }

    const stateBook: BookState = {
      id: newId.trim().toUpperCase(),
      title: newTitle.trim(),
      author: newAuthor.trim(),
      type: newType,
      isBorrowed: false,
      shelfLocation: newType === "Physical" ? shelfLoc : undefined,
      fileSizeMB: newType === "Digital" ? fileSize : undefined,
      downloadUrl: newType === "Digital" ? downUrl : undefined,
    };

    let javaStatement = "";
    if (newType === "Physical") {
      javaStatement = `Book newBook = new PhysicalBook("${stateBook.id}", "${stateBook.title}", "${stateBook.author}", "${shelfLoc}");\nmyLibrary.addBook(newBook);`;
    } else {
      javaStatement = `Book newBook = new EBook("${stateBook.id}", "${stateBook.title}", "${stateBook.author}", ${fileSize}, "${downUrl}");\nmyLibrary.addBook(newBook);`;
    }

    onAddBook(stateBook, javaStatement);
    setShowAddModal(false);

    // Reset fields
    setNewId("");
    setNewTitle("");
    setNewAuthor("");
  };

  const handleSearchClick = () => {
    if (!searchId.trim()) return;
    const targetId = searchId.trim().toUpperCase();
    onLog(`myLibrary.findBookById("${targetId}");`, "codeLine");
    onSetActiveFile("Library.java");

    const found = books.find(b => b.id === targetId);
    if (found) {
      onLog(`SUCCESS: Found "${found.title}" by ${found.author} (${found.type === "Physical" ? "Physical - " + found.shelfLocation : "Digital E-Book - Download URL: " + found.downloadUrl})`, "success");
    } else {
      onLog(`library.BookNotFoundException: Exception: Book ID '${targetId}' was not found in the Library inventory!`, "error");
      onSetActiveFile("BookNotFoundException.java");
    }
  };

  const handleCalcAllFees = () => {
    onLog(`// Calculating overdue Late Fees polymorphically (calculateLateFee) for ${feeDays} days:`, "codeLine");
    onSetActiveFile("Book.java");
    books.forEach(b => {
      // Polymorphic fee calculation
      const rate = b.type === "Physical" ? 2.50 : 0.50;
      const calculated = feeDays * rate;
      onLog(`Book Title: '${b.title}' (${b.type === "Physical" ? "PhysicalBook class" : "EBook class"}) delay fee for ${feeDays} days overdue is $${calculated.toFixed(2)} ($${rate.toFixed(2)}/day rate)`, "info");
    });
  };

  return (
    <div className="bg-white rounded-xl shadow-lg border border-gray-100 p-4 md:p-6 lg:p-7 space-y-6">
      
      {/* Simulation Tools Row banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-gray-100 pb-4">
        <div>
          <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
            <BookOpen className="w-6 h-6 text-indigo-600" />
            <span>نظام إدارة المكتبة التفاعلي (Simulation Core)</span>
          </h2>
          <p className="text-xs text-gray-500 mt-1">تفاعل مع المكتبة وشاهد كيف تعمل دوال الجافا وراثة، تغليفاً، وتعاملاً مع الأخطاء.</p>
        </div>
        <button
          onClick={() => {
            setNewId("B" + String(books.length + 1).padStart(3, "0"));
            setShowAddModal(true);
          }}
          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all shadow cursor-pointer self-stretch sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>إضافة كتاب جديد (Add Book Object)</span>
        </button>
      </div>

      {/* Visual Catalog Grid */}
      <div className="space-y-3">
        <h4 className="text-xs font-bold uppercase tracking-wider text-gray-400">
          Library Memory Store (ArrayList&lt;Book&gt;) :
        </h4>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {books.map((book) => (
            <div 
              key={book.id} 
              className={`rounded-xl border p-4 flex flex-col justify-between transition-all duration-300 hover:shadow-md ${
                book.isBorrowed 
                  ? "bg-slate-50 border-gray-200 opacity-80" 
                  : "bg-white border-indigo-50/70 shadow-sm"
              }`}
            >
              <div>
                <div className="flex items-center justify-between gap-2">
                  <span className="font-mono text-[10px] font-bold px-2 py-0.5 rounded bg-gray-100 text-gray-600 shrink-0">
                    ID: {book.id}
                  </span>
                  
                  {book.type === "Physical" ? (
                    <span className="text-[10px] bg-sky-50 text-sky-700 border border-sky-100 px-2 py-0.5 rounded-full font-semibold flex items-center gap-1 shrink-0">
                      <MapPin className="w-3 h-3 text-sky-500" />
                      <span>Physical - {book.shelfLocation}</span>
                    </span>
                  ) : (
                    <span className="text-[10px] bg-amber-50 text-amber-700 border border-amber-100 px-2 py-0.5 rounded-full font-semibold flex items-center gap-1 shrink-0">
                      <CloudDownload className="w-3 h-3 text-amber-500" />
                      <span>E-Book - {book.fileSizeMB}MB</span>
                    </span>
                  )}
                </div>

                <h3 className="text-sm font-bold text-gray-800 mt-2 line-clamp-1">{book.title}</h3>
                <p className="text-xs text-gray-500">{book.author}</p>
              </div>

              {/* Individual Item Operations */}
              <div className="mt-4 pt-3 border-t border-gray-50 flex items-center justify-between gap-2">
                <div className="flex items-center gap-1">
                  <span className={`w-2.5 h-2.5 rounded-full ${book.isBorrowed ? "bg-amber-400" : "bg-emerald-500"}`}></span>
                  <span className="text-[11px] font-semibold text-gray-600">
                    {book.isBorrowed ? "مستعار (Borrowed)" : "متوفر (Available)"}
                  </span>
                </div>

                <div className="flex gap-1.5">
                  <button
                    onClick={() => onBorrowBook(book.id)}
                    className={`text-xs px-3 py-1.5 rounded-md font-semibold transition-all cursor-pointer ${
                      book.isBorrowed
                        ? "bg-rose-50 hover:bg-rose-100 text-rose-600"
                        : "bg-emerald-50 hover:bg-emerald-100 text-emerald-800"
                    }`}
                  >
                    {book.isBorrowed ? "استعارة ثانية ⚠️" : "استعارة (Borrow)"}
                  </button>
                  <button
                    onClick={() => onReturnBook(book.id)}
                    disabled={!book.isBorrowed}
                    className="text-xs px-2.5 py-1.5 bg-gray-100 hover:bg-gray-200 disabled:opacity-40 disabled:hover:bg-gray-100 text-gray-700 rounded-md font-medium transition-all cursor-pointer"
                  >
                    إرجاع (Return)
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Auxiliary interactive forms (Search, Delayed Overdue Calculations) */}
      <div className="bg-slate-50 rounded-xl p-4 border border-gray-100 grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Search simulation (Exception testing) */}
        <div className="space-y-2">
          <label className="text-xs font-bold text-gray-700 block">
            البحث في الـ Library الفئة (تأثير Exception Handling)
          </label>
          <p className="text-[10px] text-gray-500">ابحث عن قيمة ID غير موجودة (مثال: B999) لتجربة معالجة الخطأ استباقياً</p>
          <div className="flex gap-2">
            <input
              type="text"
              value={searchId}
              onChange={(e) => setSearchId(e.target.value)}
              placeholder="مثال: B001 أو B999"
              className="flex-1 bg-white border border-gray-200 px-3 py-1.5 rounded-lg text-xs outline-none focus:border-indigo-500 uppercase font-mono"
            />
            <button
              onClick={handleSearchClick}
              className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1 cursor-pointer select-none shrink-0"
            >
              <Search className="w-3.5 h-3.5" />
              <span>بحث (findBook)</span>
            </button>
          </div>
        </div>

        {/* Polymorphism Demonstration */}
        <div className="space-y-2">
          <label className="text-xs font-bold text-gray-700 block">
            حساب غرامات التأخير بتعدد الأشكال (Polymorphism)
          </label>
          <p className="text-[10px] text-gray-500">يرث كلا من Physical و EBook دالة حساب التأخير، بضربها بالمعيار الخاص بكل فئة.</p>
          <div className="flex items-center gap-2">
            <div className="flex-1 flex items-center gap-2 border bg-white border-gray-200 rounded-lg px-2 py-1">
              <span className="text-[11px] text-gray-500 font-medium font-mono shrink-0">أيام التأجير:</span>
              <input
                type="number"
                value={feeDays}
                onChange={(e) => setFeeDays(Math.max(0, parseInt(e.target.value) || 0))}
                className="w-full bg-transparent px-1 font-mono text-xs outline-none"
              />
            </div>
            <button
              onClick={handleCalcAllFees}
              className="px-3 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1 cursor-pointer select-none shrink-0"
            >
              <Calendar className="w-3.5 h-3.5" />
              <span>احسب polymorphically</span>
            </button>
          </div>
        </div>

      </div>

      {/* Add book Object popup modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4 backdrop-blur-xs select-none animate-fadeIn">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-gray-100 relative">
            
            <h3 className="text-md font-bold text-gray-950 mb-4 border-b pb-2 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-indigo-500 animate-pulse" />
              <span>Add Book Object to Library ArrayList</span>
            </h3>

            <form onSubmit={handleSubmitAdd} className="space-y-4">
              {/* Type toggle */}
              <div>
                <span className="text-xs font-semibold text-gray-600 block mb-2">نوع الفئة الفرعية (Subclass Type) :</span>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setNewType("Physical")}
                    className={`p-2 py-1.5 rounded-lg border text-xs font-semibold transition-all ${
                      newType === "Physical"
                        ? "bg-sky-50 border-sky-500 text-sky-700"
                        : "bg-white border-gray-200 text-gray-500 hover:bg-gray-50"
                    }`}
                  >
                    PhysicalBook (وراثة)
                  </button>
                  <button
                    type="button"
                    onClick={() => setNewType("Digital")}
                    className={`p-2 py-1.5 rounded-lg border text-xs font-semibold transition-all ${
                      newType === "Digital"
                        ? "bg-amber-50 border-amber-500 text-amber-700"
                        : "bg-white border-gray-200 text-gray-500 hover:bg-gray-50"
                    }`}
                  >
                    EBook (وراثة)
                  </button>
                </div>
              </div>

              {/* General details */}
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[11px] font-semibold text-gray-600 block">ID الرمز (Unique Key) :</label>
                  <input
                    type="text"
                    value={newId}
                    onChange={(e) => setNewId(e.target.value)}
                    required
                    className="w-full bg-slate-50 border border-gray-200 rounded-lg p-2 text-xs uppercase font-mono outline-none focus:border-indigo-500"
                    placeholder="e.g. B005"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[11px] font-semibold text-gray-600 block">المؤلف (Author) :</label>
                  <input
                    type="text"
                    value={newAuthor}
                    onChange={(e) => setNewAuthor(e.target.value)}
                    required
                    className="w-full bg-slate-50 border border-gray-200 rounded-lg p-2 text-xs outline-none focus:border-indigo-500"
                    placeholder="Robert C. Martin"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-semibold text-gray-600 block">عنوان الكتاب (Title) :</label>
                <input
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  required
                  className="w-full bg-slate-50 border border-gray-200 rounded-lg p-2 text-xs outline-none focus:border-indigo-500"
                  placeholder="Programming in Java"
                />
              </div>

              {/* Subclass-specific specs */}
              {newType === "Physical" ? (
                <div className="space-y-1 p-3 bg-sky-50/50 rounded-lg border border-sky-100">
                  <label className="text-[11px] font-semibold text-sky-800 block">موقع الرف الفيزيائي Shelf Location (فئة PhysicalBook) :</label>
                  <input
                    type="text"
                    value={shelfLoc}
                    onChange={(e) => setShelfLoc(e.target.value)}
                    required
                    className="w-full bg-white border border-sky-200 rounded-lg p-2 text-xs outline-none focus:border-sky-500"
                    placeholder="Shelf A-15"
                  />
                </div>
              ) : (
                <div className="space-y-3 p-3 bg-amber-50/50 rounded-lg border border-amber-100">
                  <div className="grid grid-cols-2 gap-2">
                    <div className="space-y-1">
                      <label className="text-[11px] font-semibold text-amber-800 block">حجم الملف (MB) :</label>
                      <input
                        type="number"
                        step="0.1"
                        value={fileSize}
                        onChange={(e) => setFileSize(parseFloat(e.target.value) || 12.0)}
                        required
                        className="w-full bg-white border border-amber-200 rounded-lg p-2 text-xs outline-none focus:border-amber-500"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[11px] font-semibold text-amber-800 block">رابط التحميل (URL) :</label>
                      <input
                        type="text"
                        value={downUrl}
                        onChange={(e) => setDownUrl(e.target.value)}
                        required
                        className="w-full bg-white border border-amber-200 rounded-lg p-2 text-xs outline-none focus:border-amber-500"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Controls */}
              <div className="flex items-center justify-end gap-2 pt-2 border-t mt-4">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 hover:bg-gray-100 text-gray-500 rounded-lg text-xs font-semibold cursor-pointer"
                >
                  إلغاء (Cancel)
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold cursor-pointer shadow"
                >
                  تأكيد وإضافة (Java Instantiation)
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
}
