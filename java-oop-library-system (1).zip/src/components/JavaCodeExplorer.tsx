import React, { useState } from "react";
import { javaFiles, JavaFile } from "../javaSourceCode";
import { Copy, Check, Download, Info, Code2, BookOpenCheck } from "lucide-react";

interface JavaCodeExplorerProps {
  onHighlightConcept?: (concept: string) => void;
  activeFileName?: string;
  setActiveFileName?: (name: string) => void;
}

export default function JavaCodeExplorer({ onHighlightConcept, activeFileName, setActiveFileName }: JavaCodeExplorerProps) {
  const [copied, setCopied] = useState(false);
  const [internalActiveFile, setInternalActiveFile] = useState(javaFiles[0].name);

  const activeName = activeFileName || internalActiveFile;
  const setFile = setActiveFileName || setInternalActiveFile;

  const currentFile = javaFiles.find(f => f.name === activeName) || javaFiles[0];

  const handleCopy = () => {
    navigator.clipboard.writeText(currentFile.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([currentFile.code], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = currentFile.name;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleDownloadAll = () => {
    // We can loop through all files and trigger sequentially
    javaFiles.forEach((file, index) => {
      setTimeout(() => {
        const blob = new Blob([file.code], { type: "text/plain;charset=utf-8" });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href = url;
        link.download = file.name;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
      }, index * 250); // space downloads to allow browser handling
    });
  };

  // Helper to highlight syntax keywords
  const renderCode = (codeText: string) => {
    const lines = codeText.split("\n");
    return (
      <div className="font-mono text-xs leading-5">
        {lines.map((line, idx) => {
          // simple inline highlighting of keywords (Java style)
          const highlightedLine = line
            .replace(/\b(public|private|protected|class|interface|abstract|extends|implements|override|throws|throw|try|catch|new|return|package|import|void|boolean|double|int|static|final|super|this)\b/g, '<span class="text-indigo-400 font-semibold">$1</span>')
            .replace(/\b(System|String|Book|PhysicalBook|EBook|Library|BookNotFoundException|BookAlreadyBorrowedException|Exception|ArrayList|Override)\b/g, '<span class="text-emerald-400">$1</span>')
            .replace(/("[^"]*")/g, '<span class="text-amber-300">$1</span>')
            .replace(/(\/\/.*|\/\*[\s\S]*?\*\/)/g, '<span class="text-gray-500 italic">$1</span>');

          return (
            <div key={idx} className="flex hover:bg-gray-800/40 px-2 transition-colors duration-150">
              <span className="w-8 text-right pr-3 select-none text-gray-600 block shrink-0">{idx + 1}</span>
              <span className="whitespace-pre-wrap flex-1" dangerouslySetInnerHTML={{ __html: highlightedLine || "&nbsp;" }} />
            </div>
          );
        })}
      </div>
    );
  };

  return (
    <div id="java-code-explorer" className="bg-[#1e293b] rounded-xl border border-gray-700 shadow-xl overflow-hidden flex flex-col h-full">
      {/* Tab Navigation header */}
      <div className="bg-[#0f172a] p-2 flex flex-wrap items-center justify-between gap-2 border-b border-gray-700">
        <div className="flex items-center gap-2">
          <Code2 className="w-5 h-5 text-indigo-400" />
          <span className="text-xs font-bold font-mono text-gray-200">Java OOP Classes (أكواد السورس جافا)</span>
        </div>
        
        {/* Helper download all */}
        <button
          onClick={handleDownloadAll}
          className="text-xs px-2.5 py-1 bg-indigo-600 hover:bg-indigo-700 text-white rounded font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
          title="Download all files ready for your IDE project"
        >
          <Download className="w-3.5 h-3.5" />
          <span>تحميل كامل الملفات (Download All)</span>
        </button>
      </div>

      {/* Tabs */}
      <div className="bg-[#1e293b] p-1.5 overflow-x-auto flex gap-1 border-b border-gray-700 scrollbar-thin">
        {javaFiles.map((file) => {
          const isActive = file.name === activeName;
          return (
            <button
              key={file.name}
              onClick={() => setFile(file.name)}
              className={`px-3 py-1.5 rounded text-xs font-mono transition-all shrink-0 cursor-pointer ${
                isActive
                  ? "bg-indigo-600 text-white shadow-md font-semibold"
                  : "bg-gray-800/60 text-gray-400 hover:bg-gray-800 hover:text-gray-200"
              }`}
            >
              {file.name}
            </button>
          );
        })}
      </div>

      {/* Code Editor and Info Layout */}
      <div className="flex-1 flex flex-col lg:flex-row min-h-0 overflow-y-auto">
        
        {/* Active Code Viewer */}
        <div className="flex-1 min-h-[300px] lg:min-h-0 overflow-y-auto bg-[#0a0f1d] p-3 text-gray-300 relative border-b lg:border-b-0 lg:border-r border-gray-700">
          
          {/* Quick Actions overlay */}
          <div className="absolute top-3 right-3 flex gap-2 z-10">
            <button
              onClick={handleCopy}
              className="p-1.5 rounded bg-gray-800 hover:bg-gray-700 text-gray-300 hover:text-white transition-all shadow-sm flex items-center gap-1 text-xs cursor-pointer"
              title="Copy details"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? "Copied" : "Copy"}</span>
            </button>
            <button
              onClick={handleDownload}
              className="p-1.5 rounded bg-gray-800 hover:bg-gray-700 text-gray-300 hover:text-white transition-all shadow-sm flex items-center gap-1 text-xs cursor-pointer"
              title="Download file"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download</span>
            </button>
          </div>

          <div className="overflow-x-auto pt-6">
            {renderCode(currentFile.code)}
          </div>
        </div>

        {/* OOP Explainer Side / Sub Panel */}
        <div className="w-full lg:w-80 bg-slate-900 border-t lg:border-t-0 border-gray-700 p-4 flex flex-col justify-between shrink-0">
          <div className="space-y-4">
            <div className="flex items-center gap-2 border-b border-gray-800 pb-2">
              <BookOpenCheck className="w-4 h-4 text-indigo-400" />
              <h4 className="text-xs font-bold text-gray-100 uppercase tracking-widest">
                OOP Concept Explanation (الشرح التعليمي)
              </h4>
            </div>

            {/* Local English Concept */}
            <div className="p-2.5 rounded-lg bg-indigo-950/20 shadow-inner border border-indigo-900/40">
              <span className="text-[10px] uppercase font-bold text-indigo-400 block tracking-wider font-mono">
                Key Concept :
              </span>
              <span className="text-sm font-semibold text-white">
                {currentFile.concept}
              </span>
            </div>

            {/* Local Arabic Concept */}
            <div className="p-2.5 rounded-lg bg-emerald-950/20 shadow-inner border border-emerald-900/40 text-right">
              <span className="text-[10px] uppercase font-bold text-emerald-400 block tracking-wider font-mono">
                المفهوم البرمجي :
              </span>
              <span className="text-sm font-semibold text-white">
                {currentFile.arabicConcept}
              </span>
            </div>

            {/* High level desc */}
            <div className="text-xs text-gray-400 space-y-2 mt-4 leading-relaxed">
              <p className="flex items-start gap-1 p-1">
                <Info className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
                <span>{currentFile.description}</span>
              </p>
              <hr className="border-gray-800" />
              <p className="text-right text-gray-300 text-[13px] leading-relaxed font-sans bg-slate-800/35 p-2 rounded">
                {currentFile.arabicDescription}
              </p>
            </div>
          </div>

          <div className="bg-slate-800/60 p-3 rounded-lg border border-gray-700/50 mt-4">
            <span className="text-[10px] text-gray-500 block text-center font-mono uppercase">
              Project Package Status
            </span>
            <span className="text-xs text-indigo-300 block text-center mt-1 font-mono">
              package library;
            </span>
            <div className="text-[10px] text-gray-400 text-center mt-2">
              This code complies with all University OOP homework requirements.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
