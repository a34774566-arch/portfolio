import React, { useState, useRef, useEffect } from "react";
import { Send, Sparkles, MessageSquare, Loader2, ArrowRightLeft, RefreshCw, GraduationCap } from "lucide-react";

interface Message {
  role: "user" | "model";
  text: string;
}

const PRESETS = [
  { label: "شرح الـ Encapsulation", prompt: "اشرح لي كيف تم تطبيق مفهوم التغليف (Encapsulation) في الكود بالتفصيل ومع ذكر الفئات والمتغيرات الخاصّة (getters/setters)؟" },
  { label: "شرح الـ Polymorphism", prompt: "اشرح لي بالتفصيل كيف يعمل تعدد أشكال الدوال (Polymorphism) في فئات الكتب مع إعطاء أمثلة من الكود (calculateLateFee)؟" },
  { label: "شرح الـ Exception Handling", prompt: "كيف قمنا بعمل معالجة الاستثناءات (Exception Handling)؟ اشرح استخدام try-catch والـ custom exceptions مثل BookNotFoundException." },
  { label: "كيف أشغل مشروع جافا؟", prompt: "أنا طالب جامعي، كيف يمكنني تحميل هذه الملفات وتشغيلها في بيئة تطوير جافا مثل VS Code أو NetBeans أو IntelliJ؟" }
];

export default function InteractiveTutor() {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "model",
      text: "مرحباً بك! أنا معلّم الجافا الافتراضي المساعد لك. 🎓✨\nيمكنني مساعدتك في شرح أي مفهوم برمجي موجه للكائنات (OOP) تم استخدامه في مشروع المكتبة هذا، أو إرشادك لكتابة التقارير الأكاديمية للمشروع. اختر أحد الأسئلة الجاهزة بالأسفل أو اكتب سؤالك الخاص!"
    }
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = async (textToSend: string) => {
    if (!textToSend.trim() || loading) return;

    const userMessage: Message = { role: "user", text: textToSend };
    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setLoading(true);

    try {
      // Map history for API representation
      const chatHistory = messages.map((m) => ({
        role: m.role,
        parts: [{ text: m.text }]
      }));

      const response = await fetch("/api/tutor", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: textToSend,
          chatHistory: chatHistory
        })
      });

      const data = await response.json();
      if (response.ok) {
        setMessages((prev) => [...prev, { role: "model", text: data.text }]);
      } else {
        setMessages((prev) => [
          ...prev,
          { role: "model", text: `⚠️ عذراً، واجهتني مشكلة: ${data.error || "خطأ غير معروف في الاتصال بالخادم."}` }
        ]);
      }
    } catch (err: any) {
      setMessages((prev) => [
        ...prev,
        { role: "model", text: "❌ فشل الاتصال بخادم المعلم الافتراضي. تأكد من إعداد مفتاح بيئة GEMINI_API_KEY بشكل صحيح." }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setMessages([
      {
        role: "model",
        text: "تمت إعادة تعيين محادثة المعلم الافتراضي. اسألني أي شيء بخصوص مفاهيم جافا (OOP) وسأجيبك فوراً!"
      }
    ]);
  };

  return (
    <div id="java-ai-tutor" className="bg-slate-900 rounded-xl border border-indigo-900/30 shadow-xl overflow-hidden flex flex-col h-[520px]">
      {/* Target header */}
      <div className="bg-gradient-to-r from-indigo-900 to-slate-900 p-4 border-b border-indigo-950 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <GraduationCap className="w-5 h-5 text-indigo-400" />
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-1">
              Java OOP Expert AI Tutor
              <span className="text-[10px] bg-indigo-500/20 text-indigo-300 font-semibold uppercase tracking-wider px-1.5 py-0.5 rounded">
                Gemini Active
              </span>
            </h3>
            <p className="text-[10px] text-gray-400 text-left">مساعدك الأكاديمي لشرح تفاصيل المشروع ومفاهيم OOP</p>
          </div>
        </div>
        <button
          onClick={handleReset}
          className="text-xs text-gray-400 hover:text-white flex items-center gap-1 transition-colors p-1 hover:bg-white/5 rounded cursor-pointer"
          title="Reset tutor chat"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">إعادة البدء</span>
        </button>
      </div>

      {/* Messages layout */}
      <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-slate-950/40 select-text">
        {messages.map((m, idx) => {
          const isUser = m.role === "user";
          return (
            <div key={idx} className={`flex ${isUser ? "justify-end" : "justify-start"} animate-fadeIn`}>
              <div
                className={`max-w-[85%] rounded-xl p-3.5 text-xs inline-block leading-relaxed ${
                  isUser
                    ? "bg-indigo-600 text-white rounded-br-none text-right"
                    : "bg-slate-800 text-gray-100 rounded-bl-none border border-slate-700 text-right dir-rtl whitespace-pre-wrap"
                }`}
                style={{ direction: isUser ? "ltr" : "rtl" }}
              >
                {!isUser && (
                  <div className="flex items-center gap-1.5 border-b border-slate-700/60 pb-1.5 mb-1.5 text-indigo-400 select-none">
                    <Sparkles className="w-3.5 h-3.5 animate-pulse text-indigo-400" />
                    <span className="font-bold text-[10px] uppercase font-mono tracking-widest text-indigo-400">
                      معلم جافا الافتراضي
                    </span>
                  </div>
                )}
                <div className="text-sm prose prose-invert font-sans">{m.text}</div>
              </div>
            </div>
          );
        })}
        {loading && (
          <div className="flex justify-start">
            <div className="bg-slate-800 text-gray-300 rounded-xl rounded-bl-none p-3 border border-slate-700 flex items-center gap-2">
              <Loader2 className="w-4 h-4 animate-spin text-indigo-400" />
              <span className="text-xs font-mono">المعلم الافتراضي يفكر في الإجابة...</span>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Preset Suggestions */}
      <div className="bg-slate-950 p-2 border-t border-slate-900 flex gap-2 overflow-x-auto select-none shrink-0 scrollbar-none">
        {PRESETS.map((p, i) => (
          <button
            key={i}
            onClick={() => handleSend(p.prompt)}
            disabled={loading}
            className="text-[11px] bg-slate-800 hover:bg-indigo-950/40 text-indigo-200 border border-slate-700 hover:border-indigo-800 rounded-full px-3 py-1.5 whitespace-nowrap transition-all duration-200 disabled:opacity-55 disabled:hover:bg-slate-800 cursor-pointer"
          >
            {p.label}
          </button>
        ))}
      </div>

      {/* Message input */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSend(input);
        }}
        className="p-3 bg-slate-900 border-t border-indigo-950 flex items-center gap-2 shrink-0"
      >
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="اسأل كيف يعمل هذا الكود أو اطلب شرح مفاهيم الـ OOP..."
          disabled={loading}
          className="flex-1 min-w-0 bg-slate-950 border border-indigo-900/40 focus:border-indigo-500 text-sm text-white rounded-lg px-3 py-2.5 outline-none font-sans text-right placeholder-gray-500"
          style={{ direction: "rtl" }}
        />
        <button
          type="submit"
          disabled={loading || !input.trim()}
          className="p-2.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:hover:bg-indigo-600 text-white transition-all cursor-pointer shadow flex items-center justify-center shrink-0"
        >
          <Send className="w-4 h-4 translate-x-[-1px]" />
        </button>
      </form>
    </div>
  );
}
