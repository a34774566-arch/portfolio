import React, { useState } from "react";
import { OOP_QUIZ, QuizQuestion } from "../types";
import { HelpCircle, CheckCircle, XCircle, RefreshCw, Award, BookOpen } from "lucide-react";

export default function OopQuiz() {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [selectedOpt, setSelectedOpt] = useState<number | null>(null);
  const [submitted, setSubmitted] = useState(false);
  const [score, setScore] = useState(0);
  const [quizFinished, setQuizFinished] = useState(false);

  const currentQuestion = OOP_QUIZ[currentIdx];

  const handleOptionSelect = (optIdx: number) => {
    if (submitted) return;
    setSelectedOpt(optIdx);
  };

  const handleSubmitAns = () => {
    if (selectedOpt === null || submitted) return;
    setSubmitted(true);
    if (selectedOpt === currentQuestion.correctAnswer) {
      setScore(prev => prev + 1);
    }
  };

  const handleNext = () => {
    setSelectedOpt(null);
    setSubmitted(false);
    if (currentIdx + 1 < OOP_QUIZ.length) {
      setCurrentIdx(currentIdx + 1);
    } else {
      setQuizFinished(true);
    }
  };

  const handleRestart = () => {
    setCurrentIdx(0);
    setSelectedOpt(null);
    setSubmitted(false);
    setScore(0);
    setQuizFinished(false);
  };

  return (
    <div id="oop-java-quiz" className="bg-white rounded-xl shadow-lg border border-gray-100 p-4 md:p-6 lg:p-7 flex flex-col justify-between h-full min-h-[420px]">
      <div>
        <div className="flex items-center justify-between border-b pb-3 mb-4">
          <div className="flex items-center gap-2">
            <HelpCircle className="w-5 h-5 text-indigo-600" />
            <h3 className="font-bold text-gray-900 text-sm">ألعاب اختبار مفاهيم الـ OOP (Java Quiz)</h3>
          </div>
          <span className="text-xs bg-slate-100 px-2 py-1 rounded-full font-semibold text-gray-500 font-mono">
            {quizFinished ? "Compelete" : `Question ${currentIdx + 1} of ${OOP_QUIZ.length}`}
          </span>
        </div>

        {!quizFinished ? (
          <div className="space-y-4 animate-fadeIn">
            <div>
              <span className="text-[10px] bg-indigo-50 text-indigo-700 border border-indigo-100 font-bold px-2 py-0.5 rounded-full uppercase tracking-wider font-mono">
                {currentQuestion.oopConcept}
              </span>
              <h4 className="text-sm md:text-md text-gray-800 font-bold mt-2 font-sans" style={{ direction: "rtl", textAlign: "right" }}>
                {currentQuestion.questionAr}
              </h4>
              <p className="text-xs text-gray-500 font-mono italic mt-1 text-left">{currentQuestion.question}</p>
            </div>

            {/* Options layout */}
            <div className="space-y-2 mt-4">
              {currentQuestion.optionsAr.map((optAr, idx) => {
                const isSelected = selectedOpt === idx;
                const isCorrect = idx === currentQuestion.correctAnswer;
                const showSuccess = submitted && isCorrect;
                const showDanger = submitted && isSelected && !isCorrect;

                let optClass = "hover:bg-slate-50 border-gray-200 text-gray-700";
                if (isSelected && !submitted) {
                  optClass = "bg-indigo-50 border-indigo-400 text-indigo-950 font-medium";
                } else if (showSuccess) {
                  optClass = "bg-emerald-50 border-emerald-400 text-emerald-950 font-semibold";
                } else if (showDanger) {
                  optClass = "bg-rose-50 border-rose-400 text-rose-950 font-semibold";
                }

                return (
                  <button
                    key={idx}
                    onClick={() => handleOptionSelect(idx)}
                    disabled={submitted}
                    className={`w-full text-right p-3 rounded-xl border text-xs sm:text-sm transition-all flex items-center justify-between gap-3 cursor-pointer ${optClass}`}
                    style={{ direction: "rtl" }}
                  >
                    <div className="flex-1">
                      <span>{optAr}</span>
                      <span className="block text-[10px] text-gray-400 font-mono font-normal mt-0.5 text-right font-sans lowercase">
                        {currentQuestion.options[idx]}
                      </span>
                    </div>

                    {/* Visual Check Indicators */}
                    {submitted && isCorrect && <CheckCircle className="w-5 h-5 text-emerald-500 shrink-0" />}
                    {submitted && isSelected && !isCorrect && <XCircle className="w-5 h-5 text-rose-500 shrink-0" />}
                  </button>
                );
              })}
            </div>

            {/* Response explanation text */}
            {submitted && (
              <div className="bg-slate-50 border border-gray-100 p-3 rounded-xl text-right animate-fadeIn" style={{ direction: "rtl" }}>
                <span className="text-[10px] font-bold text-indigo-600 block uppercase font-mono tracking-wider">
                  شرح الحل المفهومي :
                </span>
                <p className="text-xs text-gray-700 font-medium leading-relaxed mt-1">
                  {currentQuestion.explanationAr}
                </p>
                <span className="block text-[10px] text-gray-400 font-mono mt-1 text-left" style={{ direction: "ltr" }}>
                  {currentQuestion.explanation}
                </span>
              </div>
            )}
          </div>
        ) : (
          <div className="text-center py-6 space-y-4 animate-fadeIn">
            <div className="inline-flex p-3 bg-indigo-50 text-indigo-600 rounded-full">
              <Award className="w-12 h-12 text-indigo-500" />
            </div>

            <div>
              <h3 className="text-base font-bold text-gray-900">أحسنت! أكملت اختبار المفاهيم بنجاح</h3>
              <p className="text-xs text-gray-500 mt-1">نتيجتك النهائية لمعرفة مفاهيم الـ OOP في لغة جافا:</p>
            </div>

            <div className="text-3xl font-bold text-indigo-600 font-mono">
              {score} / {OOP_QUIZ.length}
            </div>

            <p className="text-xs text-gray-600 max-w-sm mx-auto" style={{ direction: "rtl" }}>
              {score === OOP_QUIZ.length 
                ? "درجة كاملة! أنت تتقن مفاهيم الكائنات الموجهة (OOP) ومعالجة الأخطاء والتغليف والمجموعات بشكل ممتاز! جاهز للتسليم الأكاديمي."
                : "ممتاز! يمكنك إعادة المحاولة للحصول على الدرجة الكاملة والتعرف على بقية المفاهيم بالتفصيل."}
            </p>
          </div>
        )}
      </div>

      {/* Button controls */}
      <div className="mt-6 pt-4 border-t border-gray-50 flex justify-end">
        {quizFinished ? (
          <button
            onClick={handleRestart}
            className="w-full sm:w-auto px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-lg flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow"
          >
            <RefreshCw className="w-4 h-4" />
            <span>إعادة الاختبار (Restart)</span>
          </button>
        ) : (
          <div className="w-full flex justify-between gap-3">
            <span className="text-xs text-gray-400 mt-2">
              Score: {score}
            </span>
            <button
              onClick={submitted ? handleNext : handleSubmitAns}
              disabled={selectedOpt === null}
              className={`px-5 py-2 rounded-lg text-xs font-semibold transition-all shadow cursor-pointer ${
                selectedOpt === null 
                  ? "bg-gray-100 text-gray-400 shadow-none cursor-not-allowed"
                  : "bg-indigo-600 hover:bg-indigo-700 text-white"
              }`}
            >
              {submitted ? "السؤال التالي (Next)" : "تأكيد الإجابة (Submit)"}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
