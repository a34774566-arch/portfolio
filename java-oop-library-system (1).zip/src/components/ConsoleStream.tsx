import React, { useEffect, useRef } from "react";
import { Terminal, Trash2, ShieldAlert, Sparkles, Code } from "lucide-react";
import { ConsoleLog } from "../types";

interface ConsoleStreamProps {
  logs: ConsoleLog[];
  onClear: () => void;
}

export default function ConsoleStream({ logs, onClear }: ConsoleStreamProps) {
  const terminalEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to the bottom of logs on changes
  useEffect(() => {
    terminalEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [logs]);

  return (
    <div id="java-jvm-console" className="bg-[#1e1e1e] rounded-xl border border-gray-800 shadow-2xl flex flex-col h-[320px] overflow-hidden">
      {/* Console Header */}
      <div className="bg-[#252526] px-4 py-2.5 flex items-center justify-between border-b border-gray-800">
        <div className="flex items-center gap-2">
          <Terminal className="w-4 h-4 text-emerald-400" />
          <span className="font-mono text-xs font-bold text-gray-300">
            JVM Execution Console & Compiler Output (جافا كونسول)
          </span>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            <span className="inline-block w-2.5 h-2.5 bg-emerald-500 rounded-full animate-pulse"></span>
            <span className="font-mono text-[10px] text-gray-400 font-semibold uppercase tracking-wider">
              JVM Active
            </span>
          </div>
          <button
            onClick={onClear}
            className="p-1 hover:bg-[#323233] text-gray-400 hover:text-white rounded transition-colors duration-200"
            title="Clear Console (مسح الكونسول)"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Terminal Content Panel */}
      <div className="flex-1 p-4 overflow-y-auto font-mono text-xs leading-relaxed space-y-2 select-text">
        {logs.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center text-gray-500 space-y-2">
            <Code className="w-8 h-8 text-gray-700 animate-pulse" />
            <p className="text-xs">المكتبة جاهزة للعمل. قم بإجراء العمليات لرؤية نواتج تشغيل جافا هنا.</p>
            <p className="text-[10px] text-gray-600">No output logs generated yet. Trigger library events above!</p>
          </div>
        ) : (
          logs.map((log) => {
            let colorClass = "text-gray-300";
            let prefix = "📎";

            if (log.type === "success") {
              colorClass = "text-emerald-400 font-semibold";
              prefix = "✅ SUCCESS:";
            } else if (log.type === "error") {
              colorClass = "text-rose-400 font-bold bg-rose-950/20 px-1 py-0.5 rounded border border-rose-900/30";
              prefix = "❌ EXCEPTION THROWN:";
            } else if (log.type === "warning") {
              colorClass = "text-amber-400 font-medium";
              prefix = "⚠️ WARNING:";
            } else if (log.type === "info") {
              colorClass = "text-sky-400";
              prefix = "💻 [System.out]:";
            } else if (log.type === "codeLine") {
              colorClass = "text-indigo-300 border-l-2 border-indigo-500 pl-2 bg-indigo-950/10 italic text-[11px]";
              prefix = "⚙️ Executing Java:";
            }

            return (
              <div key={log.id} className="transition-all duration-300 animate-fadeIn">
                <div className="flex items-start gap-1 p-0.5 rounded hover:bg-white/[0.02]">
                  <span className="text-gray-600 text-[10px] mr-2 select-none shrink-0">{log.timestamp}</span>
                  <div className="whitespace-pre-wrap">
                    <span className="font-semibold text-[10px] uppercase mr-1 opacity-75 select-none shrink-0 italic">{prefix}</span>{" "}
                    <span className={colorClass}>{log.message}</span>
                  </div>
                </div>
              </div>
            );
          })
        )}
        <div ref={terminalEndRef} />
      </div>

      {/* Compiler Helper Footer Banner */}
      <div className="bg-[#181818] border-t border-gray-800 px-4 py-1.5 flex items-center justify-between text-[11px] font-mono select-none text-gray-500 shrink-0">
        <span>Standard Output (System.out.println) stream</span>
        <span className="flex items-center gap-1">
          <ShieldAlert className="w-3.5 h-3.5 text-indigo-400" />
          <span>Auto-catching BookExceptions</span>
        </span>
      </div>
    </div>
  );
}
