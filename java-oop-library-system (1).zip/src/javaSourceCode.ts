export interface JavaFile {
  name: string;
  description: string;
  arabicDescription: string;
  concept: string;
  arabicConcept: string;
  code: string;
}

export const javaFiles: JavaFile[] = [
  {
    name: "Borrowable.java",
    description: "An interface defining library borrowing behaviors. Shows the Interface concept in OOP.",
    arabicDescription: "واجهة برمجية (Interface) تحدد العمليات الأساسية للاستعارة والإرجاع.",
    concept: "Interface",
    arabicConcept: "الواجهات (Interfaces)",
    code: `package library;

/**
 * Interface defining borrowable operations.
 * Demonstrates the concept of Interfaces.
 */
public interface Borrowable {
    void borrowBook() throws BookAlreadyBorrowedException;
    void returnBook();
    boolean isBorrowed();
}
`
  },
  {
    name: "Book.java",
    description: "An abstract base class representing a generic book. It implements Borrowable and demonstrates Encapsulation and Abstract Classes.",
    arabicDescription: "فئة مجردة (Abstract Class) تمثل كتابًا عامًا وتقوم بتطبيق واجهة Borrowable. توضح التغليف والفئات المجردة.",
    concept: "Abstract Class & Encapsulation",
    arabicConcept: "الفئات المجردة والتغليف (Encapsulation)",
    code: `package library;

/**
 * Abstract class representing a generic Book.
 * Demonstrates Inheritance (base), Encapsulation, and Abstract Classes.
 */
public abstract class Book implements Borrowable {
    // Encapsulation: Private members
    private String bookId;
    private String title;
    private String author;
    private boolean borrowed;

    // Constructor
    public Book(String bookId, String title, String author) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
        this.borrowed = false; // Initially not borrowed
    }

    // Encapsulation: Getters and Setters
    public String getBookId() {
        return bookId;
    }

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    // Implementing Borrowable interface methods
    @Override
    public boolean isBorrowed() {
        return borrowed;
    }

    @Override
    public void borrowBook() throws BookAlreadyBorrowedException {
        if (this.borrowed) {
            // Throws custom exception if already borrowed (Exception Handling)
            throw new BookAlreadyBorrowedException("Error: Book '" + title + "' is already borrowed!");
        }
        this.borrowed = true;
    }

    @Override
    public void returnBook() {
        this.borrowed = false;
    }

    // Abstract method: must be implemented by concrete subclasses (Polymorphism)
    public abstract double calculateLateFee(int daysOverdue);

    // Abstract method to describe book type
    public abstract String getBookType();

    // Regular polymorphic method
    public void displayDetails() {
        System.out.println("[" + getBookType() + "] ID: " + bookId + ", Title: " + title + ", Author: " + author + ", Status: " + (borrowed ? "Borrowed" : "Available"));
    }
}
`
  },
  {
    name: "PhysicalBook.java",
    description: "A concrete subclass representing a printed book. It inherits Book and overrides late fee calculation and details display, exemplifying Inheritance and Polymorphism.",
    arabicDescription: "فئة وارثة تمثل كتابًا ورقيًا مطبوعًا. ترث من Book وتحدد قيمة غرامة التأخير وموقع الرف. توضح الوراثة وتعدد الأشكال.",
    concept: "Inheritance & Polymorphism",
    arabicConcept: "الوراثة وتعدد الأشكال (Inheritance & Polymorphism)",
    code: `package library;

/**
 * Concrete subclass representing a physical printed book.
 * Demonstrates Inheritance and Polymorphism (method overriding).
 */
public class PhysicalBook extends Book {
    private String shelfLocation;
    private static final double LATE_FEE_RATE = 2.50; // $2.50 per day

    // Constructor calling helper parent constructor
    public PhysicalBook(String bookId, String title, String author, String shelfLocation) {
        super(bookId, title, author); // Inheritance
        this.shelfLocation = shelfLocation;
    }

    public String getShelfLocation() {
        return shelfLocation;
    }

    public void setShelfLocation(String shelfLocation) {
        this.shelfLocation = shelfLocation;
    }

    // Polymorphism: Subclass-specific implementation of abstract method
    @Override
    public double calculateLateFee(int daysOverdue) {
        return daysOverdue * LATE_FEE_RATE;
    }

    @Override
    public String getBookType() {
        return "Physical Book";
    }

    // Polymorphism: Overriding display details to include shelf location
    @Override
    public void displayDetails() {
        super.displayDetails();
        System.out.println("   -> Shelf Location: " + shelfLocation + " | Late Fee Rate: $" + LATE_FEE_RATE + "/day");
    }
}
`
  },
  {
    name: "EBook.java",
    description: "A concrete subclass representing a digital electronic book, extending Book with specific download URLs and cheap digital late fees.",
    arabicDescription: "فئة وارثة تمثل كتابًا إلكترونيًا رقميًا. ترث من Book وتحدد حجم الملف ورابط التحميل وغرامة تأخير منخفضة.",
    concept: "Inheritance & Polymorphism (Alternative)",
    arabicConcept: "الوراثة وتعدد الأشكال (تطبيق ثانٍ)",
    code: `package library;

/**
 * Concrete subclass representing a digital E-Book.
 * Demonstrates Inheritance and Polymorphism.
 */
public class EBook extends Book {
    private double fileSizeMB;
    private String downloadUrl;
    private static final double LATE_FEE_RATE = 0.50; // $0.50 per day for ebooks

    public EBook(String bookId, String title, String author, double fileSizeMB, String downloadUrl) {
        super(bookId, title, author); // Inheritance
        this.fileSizeMB = fileSizeMB;
        this.downloadUrl = downloadUrl;
    }

    public double getFileSizeMB() {
        return fileSizeMB;
    }

    public void setFileSizeMB(double fileSizeMB) {
        this.fileSizeMB = fileSizeMB;
    }

    public String getDownloadUrl() {
        return downloadUrl;
    }

    public void setDownloadUrl(String downloadUrl) {
        this.downloadUrl = downloadUrl;
    }

    // Polymorphism: Subclass-specific implementation of late fee calculation
    @Override
    public double calculateLateFee(int daysOverdue) {
        return daysOverdue * LATE_FEE_RATE;
    }

    @Override
    public String getBookType() {
        return "E-Book";
    }

    // Polymorphism: Overriding display details to include file specifications
    @Override
    public void displayDetails() {
        super.displayDetails();
        System.out.println("   -> Digital Link: " + downloadUrl + " | Size: " + fileSizeMB + "MB | Late Fee Rate: $" + LATE_FEE_RATE + "/day");
    }
}
`
  },
  {
    name: "Library.java",
    description: "Manages books dynamic storage using ArrayList, highlighting Search logic and Exception Throwing.",
    arabicDescription: "فئة إدارة المكتبة وتخزين الكتب بشكل ديناميكي عبر ArrayList. توضح التكرار والبحث وإطلاق الأخطاء والمجموعات.",
    concept: "ArrayLists & Exception Throws",
    arabicConcept: "المجموعات المرنة وإطلاق الأخطاء (ArrayList & Throws)",
    code: `package library;

import java.util.ArrayList;

/**
 * Class representing the Library manager.
 * Demonstrates the use of ArrayLists and Exception propagation (Exception Handling).
 */
public class Library {
    // Storing polymorphic list of books using ArrayList (Abstract class type reference)
    private ArrayList<Book> bookCollection;

    public Library() {
        this.bookCollection = new ArrayList<>();
    }

    // Add Book
    public void addBook(Book book) {
        bookCollection.add(book);
        System.out.println("System: Added '" + book.getTitle() + "' to library catalogs.");
    }

    // Search Book by ID - Throws custom BookNotFoundException if missing
    public Book findBookById(String bookId) throws BookNotFoundException {
        for (Book book : bookCollection) {
            if (book.getBookId().equalsIgnoreCase(bookId)) {
                return book;
            }
        }
        // Exception Handling: Throws checked exception when book is not found
        throw new BookNotFoundException("Exception: Book ID '" + bookId + "' was not found in the Library inventory!");
    }

    // Borrow operation logic coordinating checks and exceptions
    public void borrowBook(String bookId) throws BookNotFoundException, BookAlreadyBorrowedException {
        // Step 1: Find book (can throw BookNotFoundException)
        Book book = findBookById(bookId);
        
        // Step 2: Borrow book (can throw BookAlreadyBorrowedException)
        book.borrowBook();
        
        System.out.println("System: Borrowed successfully! Enjoy reading '" + book.getTitle() + "'.");
    }

    // Return book operation
    public void returnBook(String bookId) throws BookNotFoundException {
        Book book = findBookById(bookId);
        if (!book.isBorrowed()) {
            System.out.println("System Warning: '" + book.getTitle() + "' was not rented out.");
            return;
        }
        book.returnBook();
        System.out.println("System: Returned successfully! '" + book.getTitle() + "' is now available.");
    }

    // Display all books showing polymorphism in action
    public void listAllBooks() {
        System.out.println("\n--- Library Catalog Listing (Polymorphic View) ---");
        if (bookCollection.isEmpty()) {
            System.out.println("(No books available in catalog)");
            return;
        }
        for (Book book : bookCollection) {
            // Polymorphism: Calls displayDetails() which executes subtype version at runtime!
            book.displayDetails();
        }
        System.out.println("-----------------------------------------------\n");
    }

    // Getter for books (to facilitate simulation)
    public ArrayList<Book> getBookCollection() {
        return bookCollection;
    }
}
`
  },
  {
    name: "BookNotFoundException.java",
    description: "Custom exception class thrown when searching for a book ID that does not exist. Demonstrates Exception Handling inheritance.",
    arabicDescription: "استثناء مخصص يتم إطلاقه عندما لا يتواجد معرف الكتاب المطلوب في المكتبة. يوضح وراثة الاستثناءات ومعالجة الأخطاء.",
    concept: "Exception Handling Class",
    arabicConcept: "تصميم الاستثناءات المخصصة (Exceptions)",
    code: `package library;

/**
 * Custom checked Exception for non-existent books.
 * Demonstrates custom Exception Handling and inheritance from Exception.
 */
public class BookNotFoundException extends Exception {
    
    // Constructor passing message to parent Exception class
    public BookNotFoundException(String message) {
        super(message);
    }
}
`
  },
  {
    name: "BookAlreadyBorrowedException.java",
    description: "Custom exception class thrown when trying to borrow an already checked-out book. Demonstrates Exception Handling.",
    arabicDescription: "استثناء مخصص يتم إطلاقه عند محاولة استعارة كتاب مستعار بالفعل. يوضح معالجة الأخطاء الاستباقية.",
    concept: "Exception Handling Class (Alternative)",
    arabicConcept: "تصميم استثناء ثانٍ مخصص",
    code: `package library;

/**
 * Custom checked Exception for already-borrowed books.
 * Demonstrates Exception Handling structure.
 */
public class BookAlreadyBorrowedException extends Exception {
    
    public BookAlreadyBorrowedException(String message) {
        super(message);
    }
}
`
  },
  {
    name: "Main.java",
    description: "The execution entry point classes. Prepopulates the library catalogs, tests search, demonstrates try-catch exception triggers, polymorphically lists books, and runs overdue fee calculations.",
    arabicDescription: "الفئة الرئيسية (Main Class) التي تحتوي على دالة التشغيل الرئيسية. تقوم بتهيئة المكتبة وتجربة الاستعارة ومعالجة الأخطاء وحساب غرامات التأخير المتعددة.",
    concept: "Application Entry & Try-Catch",
    arabicConcept: "نقطة تشغيل البرنامج والمعالجة بـ Try-Catch",
    code: `package library;

public class Main {
    public static void main(String[] args) {
        System.out.println("==================================================");
        System.out.println("=== Starting Java Interactive Library Simulator ===");
        System.out.println("==================================================\n");

        // 1. Instantiating Library Manager (Objects & Classes)
        Library myLibrary = new Library();

        // 2. Prepopulating inventory polymorphically (Inheritance, Polymorphism)
        // We instantiate concrete PhysicalBook and EBook subclasses, but reference them as Book base class!
        Book book1 = new PhysicalBook("B001", "Clean Code", "Robert C. Martin", "Shelf A-12");
        Book book2 = new EBook("B002", "Effective Java", "Joshua Bloch", 12.4, "https://example.com/effective-java.pdf");
        Book book3 = new PhysicalBook("B003", "Design Patterns", "Erich Gamma", "Shelf B-04");
        Book book4 = new EBook("B004", "Java: The Complete Reference", "Herbert Schildt", 24.8, "https://example.com/java-ref.pdf");

        myLibrary.addBook(book1);
        myLibrary.addBook(book4);
        myLibrary.addBook(book2);
        myLibrary.addBook(book3);

        // 3. List catalogs (Polymorphism)
        myLibrary.listAllBooks();

        // 4. Test Borrowing with Exception Handling (try-catch)
        System.out.println("--- Scenario 1: Borrowing an Available Book ---");
        try {
            myLibrary.borrowBook("B001"); // Succeeds
        } catch (BookNotFoundException | BookAlreadyBorrowedException e) {
            System.out.println("Caught Exception: " + e.getMessage());
        }

        System.out.println("\n--- Scenario 2: Borrowing the Same Book Again (Triggers Custom Exception) ---");
        try {
            myLibrary.borrowBook("B001"); // Throws BookAlreadyBorrowedException
        } catch (BookNotFoundException | BookAlreadyBorrowedException e) {
            // Exception Handling in Action
            System.out.println("SUCCESSFULLY CAUGHT EXCEPTION: " + e.getMessage());
        }

        System.out.println("\n--- Scenario 3: Borrowing a Non-Existent Book (Triggers NotFound Exception) ---");
        try {
            myLibrary.borrowBook("B999"); // Throws BookNotFoundException
        } catch (BookNotFoundException e) {
            System.out.println("SUCCESSFULLY CAUGHT SEARCH ERROR: " + e.getMessage());
        } catch (BookAlreadyBorrowedException e) {
            System.out.println("Caught other exception: " + e.getMessage());
        }

        // 5. Test Overdue Late Fees Polymorphically
        System.out.println("\n--- Scenario 4: Checking Overdue Late Fee Calculation (Polymorphism) ---");
        int delayDays = 5;
        System.out.println("Let's calculate the overdue fees for checked-out items after " + delayDays + " days overdue:");
        for (Book book : myLibrary.getBookCollection()) {
            double fee = book.calculateLateFee(delayDays);
            System.out.println("Book Title: '" + book.getTitle() + "' (" + book.getBookType() + ")");
            System.out.println("   Calculated Late Fee for " + delayDays + " days delay: $" + fee);
        }

        System.out.println("\n==================================================");
        System.out.println("=== Library Simulation Successfully Finished ! ===");
        System.out.println("==================================================");
    }
}
`
  }
];
