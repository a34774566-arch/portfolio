import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";

dotenv.config();

// Shared Gemini client setup server-side only
const apiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;
if (apiKey) {
  ai = new GoogleGenAI({
    apiKey: apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      }
    }
  });
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Route: AI Tutor Proxy
  app.post("/api/tutor", async (req, res) => {
    try {
      const { prompt, chatHistory } = req.body;
      if (!prompt) {
        return res.status(400).json({ error: "Prompt is required" });
      }

      if (!ai) {
        return res.status(503).json({
          error: "Gemini API key is not configured in this workspace. Please add GEMINI_API_KEY to your Secrets."
        });
      }

      // Convert standard chat history if supplied, or formulate direct prompt
      const systemInstruction = `You are a helpful, expert Java Computer Science University Professor.
Your job is to explain the 7 Object-Oriented Programming (OOP) concepts in Java based on our Interactive Library System:
1. Classes & Objects (الفئات والكائنات)
2. Inheritance (الوراثة)
3. Polymorphism (تعدد الأشكال)
4. Encapsulation (التغليف: setters/getters)
5. Abstract Classes or Interfaces (الفئات المجردة والواجهات)
6. ArrayLists (المجموعات الديناميكية)
7. Exception Handling (معالجة الأخطاء الاستباقية والمخصصة)

Focus on explaining clearly, with elegant examples, teaching the student with a highly educational, positive, and accurate tone.
Always prefer replying in Arabic (or bilingual Arabic/English) because the student's request is in Arabic.
When showing Java code formatting, use Markdown style format blocks.
Keep explanations concise, friendly, and structured.`;

      const contents = chatHistory && chatHistory.length > 0
        ? [...chatHistory, { role: "user", parts: [{ text: prompt }] }]
        : prompt;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: contents,
        config: {
          systemInstruction: systemInstruction,
          temperature: 0.7,
        }
      });

      const replyText = response.text || "No response generated.";
      res.json({ text: replyText });
    } catch (err: any) {
      console.error("Gemini Tutor Error:", err);
      res.status(500).json({ error: err?.message || "Internal server error during tutor processing." });
    }
  });

  // Serve static files / Vite middleware
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Server] Java Library simulation running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
