# مزاولتك – الخلفية الآمنة (Firebase)

## خطوات الإعداد
1. أنشئ مشروعًا في https://console.firebase.google.com
2. فعّل Authentication ثم Email/Password.
3. فعّل Firestore (وضع Production) وStorage.
4. رقّ المشروع إلى خطة Blaze (شرط لتشغيل Cloud Functions).
5. ثبّت الأدوات: `npm i -g firebase-tools` ثم `firebase login` ثم `firebase use --add`.
6. انشر القواعد والدوال: `cd functions && npm i && cd .. && firebase deploy`.
7. أنشئ حسابك من التطبيق، ثم نزّل ملف مفتاح الخدمة من Project settings > Service accounts وسمّه `scripts/serviceAccount.json` (لا ترفعه إلى أي مستودع)، ثم شغّل `node scripts/setAdmin.js بريدك`.
8. أضف في Firestore: وثيقة `banks/{id}` فيها (title, level, major, price, count, desc, published=true)، ومجموعة فرعية `questions` لكل سؤال فيها (text, options[], correct, explanation, sample).
9. أنشئ أكواد الخصم في `codes/MAZ10` بالحقول: percent=10 وactive=true.

## تدفق الشراء الآمن
createOrder (السعر من الخادم) ← submitPayment (رقم عملية Orange Money، ويُرفض المكرر) ← المسؤول يتحقق من وصول المبلغ في محفظته ← confirmOrder ← يُنشأ entitlement ← تُفتح الأسئلة.

## ما يضمنه هذا الهيكل
- لا يقرأ أي عميل الأسئلة ولا الإجابات الصحيحة مباشرة (قواعد Firestore).
- الإجابات الصحيحة لا تصل للطالب إلا بعد الإنهاء (أو لكل سؤال في وضع التدريب).
- الصلاحية عبر Custom Claim يفرضها الخادم، ولا يمكن للطالب تعديلها.
- لا تُخزَّن أي بيانات سرية للمحفظة.
