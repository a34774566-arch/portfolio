import React, { useEffect, useState } from "react";
import { ServerStatus, ActiveTab } from "./types";
import StatusIndicator from "./components/StatusIndicator";
import ChatPlayground from "./components/ChatPlayground";
import ImageDescriber from "./components/ImageDescriber";
import StructuredLab from "./components/StructuredLab";
import ProjectPortfolio from "./components/ProjectPortfolio";
import DeploymentGuide from "./components/DeploymentGuide";
import { Sparkles, MessageSquare, Image, Database, BookOpen, Layers, ExternalLink, Menu, X, ArrowRight, Github } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export default function App() {
  const [status, setStatus] = useState<ServerStatus | null>(null);
  const [isLoadingStatus, setIsLoadingStatus] = useState(false);
  const [activeTab, setActiveTab] = useState<ActiveTab>("chat");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const fetchStatus = async () => {
    setIsLoadingStatus(true);
    try {
      const response = await fetch("/api/status");
      if (response.ok) {
        const data = await response.json();
        setStatus(data);
      } else {
        setStatus({ status: "error", apiKeyConfigured: false, appUrl: "" });
      }
    } catch (error) {
      console.error("Failed to fetch server status:", error);
      setStatus({ status: "error", apiKeyConfigured: false, appUrl: "" });
    } finally {
      setIsLoadingStatus(false);
    }
  };

  useEffect(() => {
    fetchStatus();
  }, []);

  const tabs = [
    { id: "chat", label: "Assistant Chat", icon: MessageSquare, description: "Interactive full-stack chat session" },
    { id: "vision", label: "Vision Lab", icon: Image, description: "Multimodal image analysis model" },
    { id: "structured", label: "Schema Lab", icon: Database, description: "JSON entity extraction schemas" },
    { id: "portfolio", label: "Portfolios", icon: Layers, description: "Dynamic curated demo projects" },
    { id: "guide", label: "Sharing Guide", icon: BookOpen, description: "Standalone link & deployment steps" },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-indigo-600/30 selection:text-indigo-200">
      {/* Background radial glow */}
      <div className="fixed inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-indigo-950/20 via-slate-950 to-slate-950 pointer-events-none z-0" />

      {/* Main Container */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Header Section */}
        <header className="border-b border-slate-900 pb-5 mb-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center shadow-lg shadow-indigo-500/20 text-white shrink-0">
              <Sparkles className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-bold text-lg sm:text-xl text-slate-100 tracking-tight">
                  Google AI Studio Project Hub
                </h1>
                <span className="hidden sm:inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-medium bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                  Demo Ready
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium">
                Full-Stack Interactive Workspace with Gemini 3.5 Flash
              </p>
            </div>
          </div>

          {/* Right Header Navigation / Links */}
          <div className="hidden md:flex items-center gap-3">
            <a
              href="https://ai.studio"
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-1 px-3 py-1.5 text-xs text-slate-400 hover:text-slate-200 transition font-medium"
            >
              Google AI Studio
              <ExternalLink className="w-3 h-3" />
            </a>
            <button
              onClick={() => {
                const url = window.location.href;
                window.open(url, "_blank");
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600/10 hover:bg-indigo-600/20 border border-indigo-500/20 text-indigo-300 rounded-lg text-xs font-semibold transition"
            >
              Open Standalone
              <ExternalLink className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Mobile menu trigger */}
          <div className="md:hidden">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-slate-400 hover:text-slate-200 transition"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </header>

        {/* Mobile Navigation Drawer */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden border-b border-slate-900 bg-slate-950/80 backdrop-blur-md mb-6 overflow-hidden rounded-xl"
            >
              <div className="p-4 space-y-2">
                {tabs.map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => {
                      setActiveTab(tab.id as ActiveTab);
                      setMobileMenuOpen(false);
                    }}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-semibold transition text-left ${
                      activeTab === tab.id
                        ? "bg-indigo-600 text-white"
                        : "bg-slate-900/40 hover:bg-slate-800 text-slate-400"
                    }`}
                  >
                    <tab.icon className="w-4 h-4" />
                    <div>
                      <p>{tab.label}</p>
                      <p className={`text-[9px] ${activeTab === tab.id ? "text-indigo-200" : "text-slate-500"}`}>
                        {tab.description}
                      </p>
                    </div>
                  </button>
                ))}
                
                <div className="border-t border-slate-900/60 pt-3 flex flex-col gap-2">
                  <button
                    onClick={() => {
                      const url = window.location.href;
                      window.open(url, "_blank");
                    }}
                    className="w-full flex items-center justify-center gap-2 py-2 bg-indigo-600 text-white rounded-lg text-xs font-bold transition"
                  >
                    Open Standalone
                    <ExternalLink className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Connection Status Panel */}
        <section className="mb-6">
          <StatusIndicator status={status} onRefresh={fetchStatus} isLoading={isLoadingStatus} />
        </section>

        {/* Main Workspace Layout */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-6 items-start">
          {/* Left Navigation Rails (Desktop Only) */}
          <nav className="hidden md:flex flex-col gap-2 md:col-span-1">
            <p className="text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1 px-3">
              Playgrounds
            </p>
            {tabs.map((tab) => {
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as ActiveTab)}
                  className={`flex items-start gap-3 p-3 rounded-xl border text-left transition relative ${
                    isActive
                      ? "bg-indigo-600/10 border-indigo-500/30 text-indigo-200"
                      : "bg-slate-900/20 border-slate-900 hover:bg-slate-900/50 hover:border-slate-800 text-slate-400"
                  }`}
                >
                  <tab.icon className={`w-4 h-4 mt-0.5 shrink-0 ${isActive ? "text-indigo-400" : "text-slate-500"}`} />
                  <div>
                    <h2 className="font-semibold text-xs sm:text-sm">{tab.label}</h2>
                    <p className="text-[10px] text-slate-500 mt-0.5 leading-snug">{tab.description}</p>
                  </div>
                  {isActive && (
                    <motion.div
                      layoutId="activeTabIndicator"
                      className="absolute right-2 top-1/2 -translate-y-1/2 w-1.5 h-1.5 bg-indigo-500 rounded-full"
                    />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Main Content Area */}
          <main className="col-span-1 md:col-span-4 min-h-[480px]">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -12 }}
                transition={{ duration: 0.18 }}
              >
                {activeTab === "chat" && <ChatPlayground status={status} />}
                {activeTab === "vision" && <ImageDescriber status={status} />}
                {activeTab === "structured" && <StructuredLab status={status} />}
                {activeTab === "portfolio" && <ProjectPortfolio status={status} />}
                {activeTab === "guide" && <DeploymentGuide />}
              </motion.div>
            </AnimatePresence>
          </main>
        </div>

        {/* Global Footer */}
        <footer className="mt-12 pt-6 border-t border-slate-900/60 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500 font-medium">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-indigo-500/40" />
            <span>Built & Compiled with Google AI Studio Build</span>
          </div>
          <div className="flex items-center gap-4">
            <span>Server Instance: Port 3000 Ingress</span>
            <a
              href="https://github.com"
              target="_blank"
              rel="noreferrer"
              className="hover:text-slate-400 transition flex items-center gap-1"
            >
              <Github className="w-3.5 h-3.5" />
              Source
            </a>
          </div>
        </footer>
      </div>
    </div>
  );
}
