export interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
}

export interface ServerStatus {
  status: string;
  apiKeyConfigured: boolean;
  appUrl: string;
}

export type ActiveTab = "chat" | "vision" | "structured" | "portfolio" | "guide";

export interface DemoProject {
  id: string;
  title: string;
  description: string;
  category: string;
  iconName: string;
  interactiveType: "summarizer" | "sentiment" | "code";
}
