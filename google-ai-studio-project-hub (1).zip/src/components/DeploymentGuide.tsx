import React from "react";
import { BookOpen, ExternalLink, HelpCircle, Shield, Code, Server, CheckCircle, Github, Heart } from "lucide-react";

export default function DeploymentGuide() {
  return (
    <div className="space-y-6">
      {/* Introduction Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg">
        <div className="flex items-start gap-4">
          <div className="p-3 bg-indigo-600/10 rounded-xl border border-indigo-500/20 text-indigo-400 shrink-0">
            <BookOpen className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-bold text-slate-200 text-base">Public Demo & Standalone Guide</h3>
            <p className="text-slate-400 text-xs sm:text-sm mt-1 leading-relaxed">
              Google AI Studio automatically builds and hosts your full-stack applications in sandboxed Cloud Run containers. Learn how to configure, share, and export your production-ready workspace!
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Sharing and URLs */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center gap-2">
            <ExternalLink className="w-4 h-4 text-indigo-400" />
            <h4 className="font-semibold text-slate-200 text-sm">Standalone Page & Public Share Links</h4>
          </div>

          <p className="text-xs text-slate-400 leading-relaxed">
            By default, the AI Studio preview loads within an iframe inside the developer editor. Some client-side APIs (like custom navigation or file downloads) are subject to iframe security sandbox restrictions.
          </p>

          <div className="space-y-3 pt-1">
            <div className="flex items-start gap-2.5 bg-slate-950/40 p-3 rounded-lg border border-slate-850">
              <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <p className="text-xs font-semibold text-slate-200">Open in New Tab</p>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Click the <strong>Open in New Tab</strong> button at the top right of the application preview inside AI Studio. This loads the applet directly as a secure standalone web page.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-2.5 bg-slate-950/40 p-3 rounded-lg border border-slate-850">
              <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <p className="text-xs font-semibold text-slate-200">The Share Workflow</p>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Click the <strong>Share</strong> button in the main AI Studio UI navigation header. This generates a clean public preview URL that you can send to partners or test live in mobile browsers.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Technical Architecture */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center gap-2">
            <Server className="w-4 h-4 text-indigo-400" />
            <h4 className="font-semibold text-slate-200 text-sm">Container Port & Network Architecture</h4>
          </div>

          <p className="text-xs text-slate-400 leading-relaxed">
            To ensure secure, high-speed routing in containerized deployments, the application relies on an Express + Vite full-stack server topology.
          </p>

          <div className="space-y-3 pt-1 text-[11px] font-mono text-slate-400">
            <div className="p-3 bg-slate-950 rounded-lg border border-slate-850/80 space-y-1">
              <p className="text-indigo-400 font-semibold text-xs font-sans mb-1">Production Start Sequence</p>
              <p><span className="text-slate-600"># Compiles server.ts into CommonJS bundle</span></p>
              <p className="text-emerald-400">npm run build</p>
              <p><span className="text-slate-600"># Direct, high-speed CJS server run</span></p>
              <p className="text-emerald-400">npm start</p>
            </div>

            <div className="p-3 bg-slate-950 rounded-lg border border-slate-850/80">
              <p className="text-indigo-400 font-semibold text-xs font-sans mb-1">Port Routing Rule</p>
              <p className="leading-relaxed">
                The reverse proxy strictly routes traffic to port <code className="text-indigo-300">3000</code>. Custom backend engines must bind to host <code className="text-indigo-300">0.0.0.0</code> and port <code className="text-indigo-300">3000</code> to prevent ingress routing timeouts.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Code Export Instructions */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
        <div className="flex items-center gap-2">
          <Code className="w-4 h-4 text-indigo-400" />
          <h4 className="font-semibold text-slate-200 text-sm">Exporting to Local Workspaces</h4>
        </div>

        <p className="text-xs text-slate-400 leading-relaxed">
          Ready to migrate to a custom hosting account or your local IDE? AI Studio makes codebase exports incredibly painless:
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1 text-xs">
          <div className="p-3 bg-slate-950/30 border border-slate-800/80 rounded-lg">
            <p className="font-semibold text-slate-300 flex items-center gap-1.5">
              <Github className="w-3.5 h-3.5 text-indigo-400" />
              1. Export to GitHub
            </p>
            <p className="text-slate-500 text-[11px] mt-1">
              Open the settings menu and select "Export to GitHub". This commits and syncs your custom components directly to a repository of your choice.
            </p>
          </div>

          <div className="p-3 bg-slate-950/30 border border-slate-800/80 rounded-lg">
            <p className="font-semibold text-slate-300 flex items-center gap-1.5">
              <Heart className="w-3.5 h-3.5 text-indigo-400" />
              2. Download as ZIP
            </p>
            <p className="text-slate-500 text-[11px] mt-1">
              Select "Export as ZIP" from the settings menu to save a local copy of your full-stack Vite + Express workspace to work with locally.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
