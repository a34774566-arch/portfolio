import React, { useState, useRef, useEffect } from "react";
import { Message, ServerStatus } from "../types";
import { Send, Bot, User, Sparkles, AlertCircle, Copy, Check, Terminal, Play, ArrowRight, CornerDownLeft } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface ChatPlaygroundProps {
  status: ServerStatus | null;
}

const PRESET_SYSTEM_INSTRUCTIONS = [
  {
    id: "helper",
    label: "Friendly Assistant",
    instruction: "You are an AI assistant that is friendly, supportive, and provides clear, detailed explanations.",
  },
  {
    id: "coder",
    label: "Senior TS Coder",
    instruction: "You are a pragmatic, highly skilled senior TypeScript developer. Answer with optimal, clean code blocks and minimal fluff.",
  },
  {
    id: "creative",
    label: "Sci-Fi Writer",
    instruction: "You are a poetic, immersive sci-fi author. Answer questions with creative descriptions, high-tech imagery, and dramatic tone.",
  },
];

const SANDBOX_RESPONSES: Record<string, string[]> = {
  helper: [
    "Hello! I am running in **AI Studio Sandbox Mode** because your API key isn't connected yet. Once you add your key, I can fetch live real-time answers from Google's Gemini models!",
    "That is a wonderful question! In a live full-stack application, this React frontend makes a secure POST request to `/api/chat` which runs server-side to shield your `GEMINI_API_KEY`.",
    "Google AI Studio allows you to test system instructions, adjust parameters (like temperature, topK, topP), and directly export clean code to React, Python, or Curl!",
  ],
  coder: [
    "// AI Studio Sandbox mode enabled\nexport function calculateFibonacci(n: number): number {\n  if (n <= 1) return n;\n  let a = 0, b = 1;\n  for (let i = 2; i <= n; i++) {\n    const temp = a + b;\n    a = b;\n    b = temp;\n  }\n  return b;\n}",
    "// Safe API Key Architecture\n// Server-side Route Handler:\n// const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });\n// Secure, robust, and client-safe.",
    "You can quickly build modular React components using Tailwind CSS classes. Split your views to keep bundle sizes low and speed up rendering cycles.",
  ],
  creative: [
    "The quantum drives of the cruiser sparkled in the midnight void of the Orion Arm, mirroring the silent binary code streaming through the ship's neural matrix...",
    "We are but digital dreamers, weaving light particles in the silicon valleys of infinite subroutines. Welcome to the sandbox, wanderer of the deep web.",
    "A cold solar wind brushed against the atmospheric dome of colony Theta-9. In the distance, the colossal AI core hummed its ancient, neon song.",
  ],
};

export default function ChatPlayground({ status }: ChatPlaygroundProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      role: "assistant",
      content: "Welcome to the **Google AI Studio Chat Playground**! I'm here to demonstrate full-stack chat capabilities. Type a message below or try configuring a custom **System Instruction** to change my persona.",
      timestamp: new Date(),
    },
  ]);
  const [inputValue, setInputValue] = useState("");
  const [systemInstruction, setSystemInstruction] = useState(PRESET_SYSTEM_INSTRUCTIONS[0].instruction);
  const [activePreset, setActivePreset] = useState("helper");
  const [isLoading, setIsLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const isKeyConfigured = !!status?.apiKeyConfigured;

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handlePresetChange = (id: string, instruction: string) => {
    setActivePreset(id);
    setSystemInstruction(instruction);
    
    // Add context message
    const presetLabel = PRESET_SYSTEM_INSTRUCTIONS.find(p => p.id === id)?.label || "New Persona";
    setMessages(prev => [
      ...prev,
      {
        id: Math.random().toString(),
        role: "assistant",
        content: `*System persona updated to: **${presetLabel}***. Let's start! Here's my new instruction:\n\n> "${instruction}"`,
        timestamp: new Date(),
      },
    ]);
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim() || isLoading) return;

    const userMsg: Message = {
      id: Math.random().toString(),
      role: "user",
      content: inputValue,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMsg]);
    setInputValue("");
    setIsLoading(true);

    try {
      if (isKeyConfigured) {
        // Live Server Request
        const response = await fetch("/api/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            messages: [...messages, userMsg].map(m => ({ role: m.role, content: m.content })),
            systemInstruction,
          }),
        });

        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.error || "Failed to query Gemini");
        }

        const data = await response.json();
        setMessages(prev => [
          ...prev,
          {
            id: Math.random().toString(),
            role: "assistant",
            content: data.text || "No response received.",
            timestamp: new Date(),
          },
        ]);
      } else {
        // Simulated Sandbox Response
        await new Promise(resolve => setTimeout(resolve, 1000));
        const pool = SANDBOX_RESPONSES[activePreset] || SANDBOX_RESPONSES.helper;
        const randomResponse = pool[Math.floor(Math.random() * pool.length)];
        
        setMessages(prev => [
          ...prev,
          {
            id: Math.random().toString(),
            role: "assistant",
            content: randomResponse,
            timestamp: new Date(),
          },
        ]);
      }
    } catch (error: any) {
      console.error(error);
      setMessages(prev => [
        ...prev,
        {
          id: Math.random().toString(),
          role: "assistant",
          content: `⚠️ **Error Querying Gemini Backend:**\n\n${error.message || "Unknown error occurred."}\n\nPlease check your server logs or make sure your API key in Settings is valid.`,
          timestamp: new Date(),
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 h-[600px] lg:h-[650px]">
      {/* Control Panel (System Instructions) */}
      <div className="lg:col-span-1 bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
        <div>
          <div className="flex items-center gap-2 mb-4">
            <Terminal className="w-4 h-4 text-indigo-400" />
            <h3 className="font-semibold text-slate-200 text-sm">System Instructions</h3>
          </div>

          <p className="text-xs text-slate-400 mb-4 leading-relaxed">
            System instructions prime the model's behavior, tone, constraints, and expertise.
          </p>

          <div className="space-y-2">
            {PRESET_SYSTEM_INSTRUCTIONS.map(preset => (
              <button
                key={preset.id}
                onClick={() => handlePresetChange(preset.id, preset.instruction)}
                className={`w-full text-left p-2.5 rounded-lg border text-xs transition flex flex-col gap-1 ${
                  activePreset === preset.id
                    ? "bg-indigo-600/10 border-indigo-500/40 text-indigo-200"
                    : "bg-slate-950/40 border-slate-800 hover:bg-slate-800/50 text-slate-400"
                }`}
              >
                <span className="font-semibold flex items-center gap-1">
                  {preset.label}
                  {activePreset === preset.id && <Sparkles className="w-3 h-3 text-indigo-400" />}
                </span>
                <span className="line-clamp-2 text-[11px] text-slate-500">{preset.instruction}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="mt-4 pt-4 border-t border-slate-800">
          <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-500 mb-1.5">
            Active Prompt Instruction
          </label>
          <textarea
            value={systemInstruction}
            onChange={(e) => {
              setSystemInstruction(e.target.value);
              setActivePreset("custom");
            }}
            className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-300 font-mono focus:outline-none focus:border-indigo-500 transition min-h-[100px] resize-none"
            placeholder="Type your own custom system instruction..."
          />
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="lg:col-span-3 bg-slate-900 border border-slate-800 rounded-xl flex flex-col h-full overflow-hidden">
        {/* Chat Header */}
        <div className="px-4 py-3 border-b border-slate-800 bg-slate-900/60 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bot className="w-5 h-5 text-indigo-400" />
            <div>
              <h4 className="font-semibold text-slate-200 text-sm">Gemini 3.5 Flash</h4>
              <p className="text-[10px] text-slate-400">
                {isKeyConfigured ? "Live API Session" : "Simulated Local Playground"}
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <span className={`w-2 h-2 rounded-full ${isKeyConfigured ? "bg-emerald-400" : "bg-amber-400"}`} />
            <span className="text-xs text-slate-400">{isKeyConfigured ? "Online" : "Sandbox"}</span>
          </div>
        </div>

        {/* Message List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-950/30">
          <AnimatePresence initial={false}>
            {messages.map((message) => {
              const isUser = message.role === "user";
              return (
                <motion.div
                  key={message.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  className={`flex gap-3 max-w-[85%] ${isUser ? "ml-auto flex-row-reverse" : ""}`}
                >
                  <div
                    className={`w-7 h-7 rounded-full shrink-0 flex items-center justify-center border ${
                      isUser
                        ? "bg-indigo-600/20 border-indigo-500/30 text-indigo-300"
                        : "bg-slate-800 border-slate-700 text-slate-300"
                    }`}
                  >
                    {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                  </div>

                  <div className="space-y-1">
                    <div
                      className={`rounded-xl px-4 py-2.5 text-xs sm:text-sm shadow-sm relative group ${
                        isUser
                          ? "bg-indigo-600 text-white rounded-tr-none"
                          : "bg-slate-800 border border-slate-800 text-slate-300 rounded-tl-none"
                      }`}
                    >
                      <div className="whitespace-pre-wrap leading-relaxed">
                        {message.content.includes("```") ? (
                          <div className="font-mono bg-slate-950 p-3 rounded-lg border border-slate-800 my-2 overflow-x-auto text-[11px] text-indigo-300">
                            {message.content}
                          </div>
                        ) : (
                          message.content
                        )}
                      </div>

                      {/* Message Actions */}
                      <button
                        onClick={() => copyToClipboard(message.content, message.id)}
                        className={`absolute -bottom-6 ${isUser ? "left-0" : "right-0"} opacity-0 group-hover:opacity-100 transition-opacity bg-slate-800 border border-slate-700 p-1 rounded hover:bg-slate-700 text-slate-400`}
                        title="Copy message"
                      >
                        {copiedId === message.id ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      </button>
                    </div>
                    <p className={`text-[9px] text-slate-500 ${isUser ? "text-right" : ""}`}>
                      {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>

          {isLoading && (
            <div className="flex gap-3 max-w-[80%]">
              <div className="w-7 h-7 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-300">
                <Bot className="w-4 h-4" />
              </div>
              <div className="bg-slate-800 border border-slate-800 text-slate-300 rounded-xl px-4 py-2.5 rounded-tl-none flex items-center gap-2">
                <span className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: "0ms" }}></span>
                <span className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: "150ms" }}></span>
                <span className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: "300ms" }}></span>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Bar */}
        <form onSubmit={handleSend} className="p-3 border-t border-slate-800 bg-slate-900/60 flex gap-2">
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder="Type a message to Gemini..."
            className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-slate-300 focus:outline-none focus:border-indigo-500 transition"
            disabled={isLoading}
          />
          <button
            type="submit"
            disabled={!inputValue.trim() || isLoading}
            className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-800 disabled:text-slate-600 text-white rounded-xl text-xs sm:text-sm font-semibold transition flex items-center gap-1.5"
          >
            <Send className="w-4 h-4" />
            <span className="hidden sm:inline">Send</span>
          </button>
        </form>
      </div>
    </div>
  );
}
