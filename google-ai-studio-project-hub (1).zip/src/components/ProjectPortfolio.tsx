import React, { useState } from "react";
import { ServerStatus } from "../types";
import { Sparkles, Code, MessageSquare, ArrowRight, CornerDownLeft, RefreshCw, BarChart2, CheckCircle2, ChevronRight, HelpCircle } from "lucide-react";
import { motion } from "motion/react";

interface ProjectPortfolioProps {
  status: ServerStatus | null;
}

interface DemoApp {
  id: string;
  name: string;
  description: string;
  icon: React.ComponentType<any>;
  color: string;
}

export default function ProjectPortfolio({ status }: ProjectPortfolioProps) {
  const [activeApp, setActiveApp] = useState<"summarizer" | "sentiment" | "explainer">("summarizer");
  const [inputText, setInputText] = useState("");
  const [output, setOutput] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [sentimentResult, setSentimentResult] = useState<{ score: number; sentiment: string; words: string[] } | null>(null);

  const isKeyConfigured = !!status?.apiKeyConfigured;

  const runSummarizer = async () => {
    if (!inputText.trim()) return;
    setIsLoading(true);
    setOutput(null);

    try {
      if (isKeyConfigured) {
        const response = await fetch("/api/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            messages: [{ role: "user", content: `Please summarize this meeting note into 3 clean, highly-professional action items:\n\n"${inputText}"` }],
            systemInstruction: "You are an executive summary bot. Return only a short paragraph followed by 3 bulleted action items.",
          }),
        });
        const data = await response.json();
        setOutput(data.text);
      } else {
        await new Promise((resolve) => setTimeout(resolve, 1200));
        setOutput(
          `📝 **Summary Portfolio Sandbox**\n\nHere is an executive consolidation of your notes:\n\n- **Project Focus**: Align deliverables with key engineering capabilities and remove technical bottlenecks.\n- **Timeline Adjustments**: Coordinate backend integration sprints starting next Monday morning.\n- **Customer Communication**: Schedule proactive feedback sessions with client team representatives.`
        );
      }
    } catch (err) {
      setOutput("An error occurred during summarization.");
    } finally {
      setIsLoading(false);
    }
  };

  const runSentiment = async () => {
    if (!inputText.trim()) return;
    setIsLoading(true);
    setSentimentResult(null);

    try {
      if (isKeyConfigured) {
        const response = await fetch("/api/structured-json", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ rawText: inputText, taskType: "feedback" }),
        });
        const data = await response.json();
        const json = data.result;
        setSentimentResult({
          score: json.sentimentScore * 100,
          sentiment: json.sentiment,
          words: json.categories,
        });
      } else {
        await new Promise((resolve) => setTimeout(resolve, 1000));
        // Check text content to make it interactive locally
        const lower = inputText.toLowerCase();
        let score = 50;
        let sentiment = "NEUTRAL";
        let words = ["Product", "Performance"];

        if (lower.includes("love") || lower.includes("great") || lower.includes("amazing") || lower.includes("good")) {
          score = 88;
          sentiment = "POSITIVE";
          words = ["Satisfaction", "Design", "UX"];
        } else if (lower.includes("bad") || lower.includes("error") || lower.includes("broken") || lower.includes("slow")) {
          score = 15;
          sentiment = "NEGATIVE";
          words = ["Latency", "Bugs", "Pricing"];
        }

        setSentimentResult({ score, sentiment, words });
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const runExplainer = async () => {
    if (!inputText.trim()) return;
    setIsLoading(true);
    setOutput(null);

    try {
      if (isKeyConfigured) {
        const response = await fetch("/api/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            messages: [{ role: "user", content: `Explain what this TypeScript block does in simple developer terms:\n\n\`\`\`typescript\n${inputText}\n\`\`\`` }],
            systemInstruction: "You are a senior tech lead. Keep explanations short, using a couple of bullet points explaining imports, logic flow, and optimization advice.",
          }),
        });
        const data = await response.json();
        setOutput(data.text);
      } else {
        await new Promise((resolve) => setTimeout(resolve, 1200));
        setOutput(
          `💻 **Code Explainer Sandbox**\n\n- **Function Overview:** Implements a reactive, optimized event hook pattern with clean state cleanups.\n- **Performance:** Correctly utilizes useCallback / memoization arrays to prevent unnecessary re-renders in large lists.\n- **Advice:** Ensure all child nodes feature stable, unique key identifiers to minimize virtual DOM reconciliation overhead.`
        );
      }
    } catch (err) {
      setOutput("An error occurred during code evaluation.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 min-h-[550px]">
      {/* Portfolio Sidebar */}
      <div className="lg:col-span-1 bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col gap-2">
        <h3 className="font-semibold text-slate-200 text-sm mb-2 px-1">Curated Mini-Apps</h3>
        
        <button
          onClick={() => {
            setActiveApp("summarizer");
            setInputText("We had our sync today. Backend team says Express routes are complete. Vite production static serving is set up in dist folder. QA team needs to verify on Chrome. We want to host a demo this Thursday at 2 PM. Let's make sure the slides are polished and we have example datasets loaded.");
            setOutput(null);
            setSentimentResult(null);
          }}
          className={`w-full text-left p-3 rounded-lg border text-xs transition flex items-start gap-3 ${
            activeApp === "summarizer"
              ? "bg-indigo-600/10 border-indigo-500/40 text-indigo-200"
              : "bg-slate-950/40 border-slate-800 hover:bg-slate-800/40 text-slate-400"
          }`}
        >
          <MessageSquare className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold">Meeting Notes Summarizer</p>
            <p className="text-[10px] text-slate-500 mt-1">Distill messy meeting notes into professional action tasks.</p>
          </div>
        </button>

        <button
          onClick={() => {
            setActiveApp("sentiment");
            setInputText("I absolutely love this new UI! It feels so fast and the animations are incredibly slick. Outstanding job.");
            setOutput(null);
            setSentimentResult(null);
          }}
          className={`w-full text-left p-3 rounded-lg border text-xs transition flex items-start gap-3 ${
            activeApp === "sentiment"
              ? "bg-indigo-600/10 border-indigo-500/40 text-indigo-200"
              : "bg-slate-950/40 border-slate-800 hover:bg-slate-800/40 text-slate-400"
          }`}
        >
          <BarChart2 className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold">Sentiment Analysis Gauge</p>
            <p className="text-[10px] text-slate-500 mt-1">Evaluate text tone and extract visual sentiment score metrics.</p>
          </div>
        </button>

        <button
          onClick={() => {
            setActiveApp("explainer");
            setInputText("const getStripe = () => {\n  if (!stripeClient) {\n    stripeClient = new Stripe(process.env.STRIPE_SECRET_KEY!);\n  }\n  return stripeClient;\n}");
            setOutput(null);
            setSentimentResult(null);
          }}
          className={`w-full text-left p-3 rounded-lg border text-xs transition flex items-start gap-3 ${
            activeApp === "explainer"
              ? "bg-indigo-600/10 border-indigo-500/40 text-indigo-200"
              : "bg-slate-950/40 border-slate-800 hover:bg-slate-800/40 text-slate-400"
          }`}
        >
          <Code className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold">Code Helper Explainer</p>
            <p className="text-[10px] text-slate-500 mt-1">Annotate TS logic flow and provide structural suggestions.</p>
          </div>
        </button>
      </div>

      {/* Workspace App */}
      <div className="lg:col-span-3 bg-slate-900 border border-slate-800 rounded-xl p-5 flex flex-col justify-between">
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-indigo-400" />
            <h4 className="font-semibold text-slate-200 text-sm">
              {activeApp === "summarizer" && "Executive Summarizer App"}
              {activeApp === "sentiment" && "Sentiment Gauge App"}
              {activeApp === "explainer" && "TypeScript Explainer App"}
            </h4>
          </div>

          <div>
            <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-500 mb-2">
              {activeApp === "summarizer" && "Input Raw Sync Notes"}
              {activeApp === "sentiment" && "Input Review / Comment"}
              {activeApp === "explainer" && "Input Code Snippet"}
            </label>
            <textarea
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-xs sm:text-sm text-slate-300 font-mono focus:outline-none focus:border-indigo-500 transition h-32"
              placeholder="Paste input content here..."
            />
          </div>

          {/* Action Trigger */}
          <button
            onClick={() => {
              if (activeApp === "summarizer") runSummarizer();
              if (activeApp === "sentiment") runSentiment();
              if (activeApp === "explainer") runExplainer();
            }}
            disabled={!inputText.trim() || isLoading}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-800 disabled:text-slate-600 text-white rounded-lg text-xs font-semibold transition flex items-center gap-1.5"
          >
            {isLoading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <ChevronRight className="w-4 h-4" />}
            Analyze with Gemini
          </button>

          {/* Output Visuals */}
          <div className="border-t border-slate-800/80 pt-4">
            <h5 className="text-[11px] font-semibold uppercase tracking-wider text-slate-500 mb-2">Analysis Results</h5>
            
            <div className="bg-slate-950/50 rounded-xl p-4 min-h-[160px] border border-slate-800/60 overflow-y-auto max-h-[220px]">
              {isLoading ? (
                <div className="flex flex-col items-center justify-center h-full space-y-2 py-8">
                  <RefreshCw className="w-5 h-5 text-indigo-400 animate-spin" />
                  <p className="text-slate-500 text-xs animate-pulse">Running processing pipelines...</p>
                </div>
              ) : activeApp === "sentiment" && sentimentResult ? (
                <div className="space-y-4">
                  {/* Gauge visualization */}
                  <div className="flex items-center gap-4">
                    <div className="w-24 h-24 rounded-full border-4 border-slate-800 flex flex-col items-center justify-center relative">
                      <span className="text-xl font-bold text-slate-200">{Math.round(sentimentResult.score)}%</span>
                      <span className="text-[9px] text-slate-500 uppercase font-semibold">Score</span>
                      {/* Gradient outline overlay */}
                      <svg className="absolute inset-0 -rotate-90 w-full h-full">
                        <circle
                          cx="44"
                          cy="44"
                          r="40"
                          className="stroke-indigo-500 stroke-[4px] fill-none"
                          strokeDasharray={251}
                          strokeDashoffset={251 - (251 * sentimentResult.score) / 100}
                          style={{ transform: "translate(4px, 4px)" }}
                        />
                      </svg>
                    </div>
                    <div className="space-y-1">
                      <div className="flex items-center gap-1.5">
                        <span className={`w-2.5 h-2.5 rounded-full ${
                          sentimentResult.sentiment === "POSITIVE"
                            ? "bg-emerald-400"
                            : sentimentResult.sentiment === "NEGATIVE"
                            ? "bg-rose-400"
                            : "bg-amber-400"
                        }`} />
                        <span className="font-bold text-slate-200 text-sm">{sentimentResult.sentiment}</span>
                      </div>
                      <p className="text-xs text-slate-400">
                        Evaluated sentiment density based on semantic word associations.
                      </p>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-1.5 pt-2">
                    {sentimentResult.words.map((w, idx) => (
                      <span key={idx} className="px-2 py-0.5 bg-slate-800 border border-slate-700 text-slate-300 text-[10px] font-semibold rounded-full">
                        {w}
                      </span>
                    ))}
                  </div>
                </div>
              ) : output ? (
                <div className="text-xs sm:text-sm text-slate-300 whitespace-pre-wrap leading-relaxed">
                  {output}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center h-full text-center space-y-2 py-8">
                  <HelpCircle className="w-8 h-8 text-slate-800" />
                  <p className="text-xs text-slate-500 max-w-[280px]">
                    Click "Analyze with Gemini" to fetch structured portfolios from the live server.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="mt-4 text-[10px] text-slate-500 italic text-right">
          Curated portfolios demonstrate standard server-side endpoints on AI Studio Cloud containers.
        </div>
      </div>
    </div>
  );
}
