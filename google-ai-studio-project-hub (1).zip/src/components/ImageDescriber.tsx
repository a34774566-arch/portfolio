import React, { useState } from "react";
import { ServerStatus } from "../types";
import { Upload, Image as ImageIcon, Sparkles, RefreshCw, AlertCircle, Eye, CornerDownLeft, FileText } from "lucide-react";
import { motion } from "motion/react";

interface ImageDescriberProps {
  status: ServerStatus | null;
}

// 1x1 colored png pixels to serve as safe placeholders
const PRESETS = [
  {
    id: "cyan_nebula",
    label: "Teal & Cyber Gradient",
    description: "An evocative cyberpunk gradient resembling digital neon dust.",
    // A tiny 10x10 teal gradient base64 to test loading
    dataUrl: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAPklEQVR42mNkYPjfgAsyMDIwMTAwMDEwMvACmXgZGBgYmBiYgExmBiYgE5uBiYgEbAYmIiRQMTERIYFmBiYgAwAtpgg9K9hH1wAAAABJRU5ErkJggg==",
  },
  {
    id: "magenta_sunset",
    label: "Cosmic Pink Pixel",
    description: "A cosmic dusk gradient suggesting deep space exploration.",
    dataUrl: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAPklEQVR42mP8z8AARAwMDEwMDIwMDEwMvECmXgYGBgYmBiYgExmBiYgE5uBiYgEbAYmIiRQMTERIYFmBiYgAwAiOBB7f2Z+7AAAAABJRU5ErkJggg==",
  }
];

export default function ImageDescriber({ status }: ImageDescriberProps) {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [customPrompt, setCustomPrompt] = useState("Explain the aesthetic mood, dominant colors, and artistic style of this image in 3 concise bullet points.");
  const [result, setResult] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const isKeyConfigured = !!status?.apiKeyConfigured;

  const handlePresetSelect = (dataUrl: string) => {
    setSelectedImage(dataUrl);
    setResult(null);
    setError(null);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      setError("Please upload an image file (PNG, JPG, WebP, etc.)");
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      setSelectedImage(reader.result as string);
      setResult(null);
      setError(null);
    };
    reader.onerror = () => {
      setError("Failed to read image file.");
    };
    reader.readAsDataURL(file);
  };

  const handleAnalyze = async () => {
    if (!selectedImage) return;
    setIsLoading(true);
    setError(null);
    setResult(null);

    try {
      if (isKeyConfigured) {
        const response = await fetch("/api/describe-image", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            image: selectedImage,
            prompt: customPrompt,
          }),
        });

        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.error || "Failed to analyze image");
        }

        const data = await response.json();
        setResult(data.text);
      } else {
        // Sandbox Simulated analysis
        await new Promise(resolve => setTimeout(resolve, 1500));
        setResult(
          `🎨 **AI Studio Vision Sandbox Analysis**\n\n1. **Aesthetic & Palette:** This is a simulated vision response. In production with a registered GEMINI_API_KEY, Gemini 3.5 Flash will inspect individual pixel matrices to detect features, colors, and gradients.\n2. **Detected Geometry:** High-contrast abstract gradient blocks representing modern minimalist tech design.\n3. **Application flow:** The base64 representation is successfully prepared and processed server-side securely.`
        );
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || "An unexpected error occurred during image description.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 min-h-[500px]">
      {/* Upload and Inputs */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 flex flex-col justify-between">
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <ImageIcon className="w-4 h-4 text-indigo-400" />
            <h3 className="font-semibold text-slate-200 text-sm">Image Source</h3>
          </div>

          {/* Drag and Drop Zone */}
          <div className="relative group">
            {selectedImage ? (
              <div className="relative h-48 sm:h-56 w-full rounded-xl overflow-hidden border border-slate-700 bg-slate-950 flex items-center justify-center">
                <img
                  src={selectedImage}
                  alt="Selected preview"
                  referrerPolicy="no-referrer"
                  className="max-h-full max-w-full object-contain"
                />
                <button
                  onClick={() => setSelectedImage(null)}
                  className="absolute top-2 right-2 px-2.5 py-1 bg-slate-900/80 hover:bg-slate-900 border border-slate-700 text-slate-300 text-xs font-semibold rounded-lg transition"
                >
                  Clear Image
                </button>
              </div>
            ) : (
              <label className="flex flex-col items-center justify-center h-48 sm:h-56 w-full border-2 border-dashed border-slate-800 hover:border-indigo-500/50 rounded-xl cursor-pointer bg-slate-950/40 hover:bg-slate-950/70 transition p-6 text-center">
                <Upload className="w-8 h-8 text-slate-500 group-hover:text-indigo-400 mb-2 transition-colors" />
                <span className="text-xs sm:text-sm font-semibold text-slate-300">Upload custom image</span>
                <span className="text-[10px] text-slate-500 mt-1">Supports JPG, PNG, WEBP</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
            )}
          </div>

          {/* Presets */}
          <div>
            <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-500 mb-2">
              Or Try a Quick Test Gradient Preset
            </label>
            <div className="grid grid-cols-2 gap-2">
              {PRESETS.map((p) => (
                <button
                  key={p.id}
                  onClick={() => handlePresetSelect(p.dataUrl)}
                  className={`p-2.5 rounded-lg border text-left transition flex flex-col gap-1 text-xs ${
                    selectedImage === p.dataUrl
                      ? "bg-indigo-600/10 border-indigo-500/40 text-indigo-300"
                      : "bg-slate-950/40 border-slate-800 hover:bg-slate-800/40 text-slate-400"
                  }`}
                >
                  <span className="font-semibold">{p.label}</span>
                  <span className="text-[10px] text-slate-500 line-clamp-1">{p.description}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Vision Prompt */}
          <div>
            <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-500 mb-1.5">
              Analysis Instruction for Gemini
            </label>
            <textarea
              value={customPrompt}
              onChange={(e) => setCustomPrompt(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-300 font-mono focus:outline-none focus:border-indigo-500 transition min-h-[70px] resize-none"
              placeholder="E.g., Describe this image..."
            />
          </div>
        </div>

        <div className="mt-4 pt-4 border-t border-slate-800">
          <button
            onClick={handleAnalyze}
            disabled={!selectedImage || isLoading}
            className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-800 disabled:text-slate-600 text-white rounded-xl text-xs sm:text-sm font-semibold transition flex items-center justify-center gap-2"
          >
            {isLoading ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                Analyzing Image...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                Run Multimodal Analysis
              </>
            )}
          </button>
        </div>
      </div>

      {/* Analysis Output */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 flex flex-col">
        <div className="flex items-center gap-2 mb-4">
          <Eye className="w-4 h-4 text-indigo-400" />
          <h3 className="font-semibold text-slate-200 text-sm">Gemini Vision Response</h3>
        </div>

        <div className="flex-1 bg-slate-950/40 border border-slate-800/60 rounded-xl p-4 overflow-y-auto text-xs sm:text-sm text-slate-300">
          {isLoading ? (
            <div className="flex flex-col items-center justify-center h-full space-y-3">
              <div className="relative">
                <div className="w-10 h-10 border-4 border-indigo-500/20 border-t-indigo-500 rounded-full animate-spin"></div>
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
                  <ImageIcon className="w-4 h-4 text-indigo-400" />
                </div>
              </div>
              <p className="text-slate-400 text-xs animate-pulse">Running server-side image evaluation...</p>
            </div>
          ) : result ? (
            <div className="space-y-3 leading-relaxed whitespace-pre-line">
              {result}
            </div>
          ) : error ? (
            <div className="flex items-start gap-2.5 text-amber-400 bg-amber-500/5 p-3 rounded-lg border border-amber-500/10">
              <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
              <p className="text-xs">{error}</p>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-full text-center space-y-2 py-10">
              <ImageIcon className="w-10 h-10 text-slate-700" />
              <div>
                <h4 className="font-semibold text-slate-400 text-xs sm:text-sm">No Image Analyzed</h4>
                <p className="text-[11px] text-slate-500 mt-1 max-w-[250px] mx-auto">
                  Select a test gradient or upload your own graphic, then click Run Multimodal Analysis.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
