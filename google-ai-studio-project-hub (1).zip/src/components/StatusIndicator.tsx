import React, { useEffect, useState } from "react";
import { ServerStatus } from "../types";
import { Shield, ShieldAlert, Sparkles, AlertCircle, RefreshCw, Server, HelpCircle, Key, Cpu, ExternalLink } from "lucide-react";

interface StatusIndicatorProps {
  status: ServerStatus | null;
  onRefresh: () => void;
  isLoading: boolean;
}

export default function StatusIndicator({ status, onRefresh, isLoading }: StatusIndicatorProps) {
  const [showTooltip, setShowTooltip] = useState(false);

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 sm:p-5 shadow-lg">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        {/* Status indicator info */}
        <div className="flex items-start gap-3">
          <div className="mt-1">
            {isLoading ? (
              <RefreshCw className="w-5 h-5 text-indigo-400 animate-spin" />
            ) : status?.apiKeyConfigured ? (
              <div className="relative">
                <span className="absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75 animate-ping"></span>
                <Shield className="w-5 h-5 text-emerald-400 relative z-10" />
              </div>
            ) : (
              <ShieldAlert className="w-5 h-5 text-amber-500 animate-pulse" />
            )}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-semibold text-slate-200 text-sm sm:text-base">
                {status?.apiKeyConfigured ? "Gemini Engine Connected" : "API Key Required for Live Demos"}
              </h3>
              <span
                className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                  status?.apiKeyConfigured
                    ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20"
                    : "bg-amber-500/10 text-amber-400 border border-amber-500/20"
                }`}
              >
                {status?.apiKeyConfigured ? "Active" : "Sandbox Mode"}
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
              {status?.apiKeyConfigured
                ? "The application's backend server is authorized to make live queries to Google Gemini 3.5 Flash."
                : "The server-side API key is not yet set. The app runs in simulated/sandbox mode. Add your secret key to enable live queries."}
            </p>
          </div>
        </div>

        {/* Action Button & Instructions */}
        <div className="flex items-center gap-2 self-start sm:self-center">
          <button
            onClick={onRefresh}
            disabled={isLoading}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-medium transition border border-slate-700 disabled:opacity-50"
            title="Refresh connection status"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? "animate-spin" : ""}`} />
            Refresh
          </button>
          
          <button
            onClick={() => setShowTooltip(!showTooltip)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600/15 hover:bg-indigo-600/20 text-indigo-400 rounded-lg text-xs font-medium transition border border-indigo-500/20"
          >
            <HelpCircle className="w-3.5 h-3.5" />
            How to configure
          </button>
        </div>
      </div>

      {/* Expanded Help Guidelines */}
      {showTooltip && (
        <div className="mt-4 pt-4 border-t border-slate-800/80 animate-fade-in text-xs sm:text-sm text-slate-300 space-y-3">
          <div className="flex items-start gap-2 bg-slate-950/40 p-3 rounded-lg border border-slate-800">
            <Key className="w-4 h-4 text-indigo-400 mt-0.5 shrink-0" />
            <div>
              <p className="font-semibold text-slate-200">Option 1: In the Google AI Studio Workspace</p>
              <p className="text-slate-400 mt-1">
                Go to the <strong className="text-indigo-300">Settings</strong> menu (top right) or look for the <strong className="text-indigo-300">Secrets / Secrets Panel</strong>. Add a new secret with the name <code className="bg-slate-900 px-1 py-0.5 rounded text-indigo-300 text-xs">GEMINI_API_KEY</code> and paste your key.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-2 bg-slate-950/40 p-3 rounded-lg border border-slate-800">
            <Server className="w-4 h-4 text-indigo-400 mt-0.5 shrink-0" />
            <div>
              <p className="font-semibold text-slate-200">Option 2: Standalone Deployment (.env File)</p>
              <p className="text-slate-400 mt-1">
                If running locally or as a standalone app, create a <code className="bg-slate-900 px-1 py-0.5 rounded text-indigo-300 text-xs">.env</code> file in the project root and add:
              </p>
              <pre className="bg-slate-950/80 p-2 rounded border border-slate-800/80 font-mono text-[11px] text-emerald-400 mt-1.5 overflow-x-auto">
                {"GEMINI_API_KEY=\"your_actual_gemini_api_key_here\""}
              </pre>
            </div>
          </div>
          
          <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1">
            <span>Security: The API Key is loaded server-side only and never sent to the browser.</span>
            <button 
              onClick={() => setShowTooltip(false)}
              className="text-indigo-400 hover:underline"
            >
              Dismiss
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
