import React, { useState } from "react";
import { ServerStatus } from "../types";
import { FileJson, Sparkles, RefreshCw, AlertCircle, Copy, Check, FileText, Database, Shield } from "lucide-react";
import { motion } from "motion/react";

interface StructuredLabProps {
  status: ServerStatus | null;
}

const PRESETS = [
  {
    id: "feedback",
    label: "Customer Feedback Review",
    rawText: `Hey team, I've been using the new billing UI and it is incredibly fast and intuitive. Kudos to the design team! However, the pricing is a bit steep for smaller agencies. Could we get a starter tier? Also, there's a minor typo on the invoices page under the "due date" header. Please check that out. We should set up a feedback call next Tuesday with our account manager.`,
  },
  {
    id: "recipe",
    label: "Messy Culinary Note",
    rawText: `Grandma's secret fudge: Mix about 2 cups of premium sugar with 3/4 cup of heavy whipping cream. Melt 1/2 stick of unsalted butter slowly. Toss in 12 oz of semi-sweet dark chocolate chips. Stir on medium heat for about 5 minutes (be careful not to burn it!). Pour into a greased baking sheet, sprinkle with sea salt, and let it cool. Super delicious but medium difficulty.`,
  },
  {
    id: "entities",
    label: "Corporate News Brief",
    rawText: `On Monday morning, Acme Corp CEO John Doe announced they are merging with CyberDyne Systems to create a new robotics venture based in Austin, Texas. The $2.4B transaction is expected to close by September 30, 2026. Regulatory filings will be submitted next week.`,
  }
];

export default function StructuredLab({ status }: StructuredLabProps) {
  const [taskType, setTaskType] = useState<"feedback" | "recipe" | "entities">("feedback");
  const [rawText, setRawText] = useState(PRESETS[0].rawText);
  const [result, setResult] = useState<any | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  
  const isKeyConfigured = !!status?.apiKeyConfigured;

  const handlePresetSelect = (id: "feedback" | "recipe" | "entities", text: string) => {
    setTaskType(id);
    setRawText(text);
    setResult(null);
    setError(null);
  };

  const copyJson = () => {
    if (!result) return;
    navigator.clipboard.writeText(JSON.stringify(result, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleExtract = async () => {
    if (!rawText.trim()) return;
    setIsLoading(true);
    setError(null);
    setResult(null);

    try {
      if (isKeyConfigured) {
        const response = await fetch("/api/structured-json", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ rawText, taskType }),
        });

        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.error || "Failed to extract JSON");
        }

        const data = await response.json();
        setResult(data.result);
      } else {
        // Sandbox simulated extraction
        await new Promise(resolve => setTimeout(resolve, 1500));
        if (taskType === "feedback") {
          setResult({
            sentiment: "POSITIVE",
            sentimentScore: 0.85,
            categories: ["UI", "Pricing", "Billing", "Customer Service"],
            keyTakeaways: [
              "Billing UI is fast and intuitive",
              "Pricing is slightly expensive for smaller teams",
              "Typo on the invoice page header"
            ],
            suggestedActions: [
              "Launch a cheaper starter tier for small agencies",
              "Fix invoice due date label typo",
              "Schedule feedback call next Tuesday"
            ]
          });
        } else if (taskType === "recipe") {
          setResult({
            recipeName: "Grandma's Secret Chocolate Fudge",
            difficulty: "Medium",
            prepTimeMinutes: 10,
            ingredients: [
              { item: "Premium sugar", quantity: "2 cups" },
              { item: "Heavy whipping cream", quantity: "3/4 cup" },
              { item: "Unsalted butter", quantity: "1/2 stick" },
              { item: "Semi-sweet dark chocolate chips", quantity: "12 oz" },
              { item: "Sea salt", quantity: "To taste" }
            ],
            steps: [
              "Melt butter and mix with sugar and whipping cream slowly",
              "Add chocolate chips and stir on medium heat for 5 minutes",
              "Pour into baking sheet and sprinkle with sea salt",
              "Cool before serving"
            ]
          });
        } else {
          setResult({
            summary: "Acme Corp is merging with CyberDyne Systems in a $2.4B robotics deal.",
            entities: [
              { name: "Acme Corp", type: "ORG" },
              { name: "John Doe", type: "PERSON" },
              { name: "CyberDyne Systems", type: "ORG" },
              { name: "Austin, Texas", type: "LOCATION" }
            ],
            datesAndDeadlines: [
              "Monday morning",
              "September 30, 2026",
              "Next week"
            ]
          });
        }
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || "An unexpected error occurred during structured JSON extraction.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 min-h-[500px]">
      {/* Unstructured Text Inputs */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 flex flex-col justify-between">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <FileText className="w-4 h-4 text-indigo-400" />
              <h3 className="font-semibold text-slate-200 text-sm">Unstructured Input</h3>
            </div>
          </div>

          {/* Quick Presets */}
          <div className="flex gap-1 overflow-x-auto pb-1 scrollbar-thin">
            {PRESETS.map((p) => (
              <button
                key={p.id}
                onClick={() => handlePresetSelect(p.id as any, p.rawText)}
                className={`px-3 py-1.5 rounded-lg border text-xs font-medium whitespace-nowrap transition shrink-0 ${
                  taskType === p.id
                    ? "bg-indigo-600/10 border-indigo-500/40 text-indigo-300"
                    : "bg-slate-950/40 border-slate-800 hover:bg-slate-800/40 text-slate-400"
                }`}
              >
                {p.label}
              </button>
            ))}
          </div>

          {/* Text Area */}
          <div>
            <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-500 mb-1.5">
              Messy Raw Text Content
            </label>
            <textarea
              value={rawText}
              onChange={(e) => setRawText(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-xs sm:text-sm text-slate-300 font-mono focus:outline-none focus:border-indigo-500 transition h-56 resize-none"
              placeholder="Paste custom feedback or culinary logs here..."
            />
          </div>
        </div>

        <div className="mt-4 pt-4 border-t border-slate-800">
          <button
            onClick={handleExtract}
            disabled={!rawText.trim() || isLoading}
            className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-800 disabled:text-slate-600 text-white rounded-xl text-xs sm:text-sm font-semibold transition flex items-center justify-center gap-2"
          >
            {isLoading ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                Querying Schema Engine...
              </>
            ) : (
              <>
                <FileJson className="w-4 h-4" />
                Extract Typed JSON Schema
              </>
            )}
          </button>
        </div>
      </div>

      {/* JSON Output Schema */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 flex flex-col justify-between">
        <div className="flex-1 flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Database className="w-4 h-4 text-indigo-400" />
              <h3 className="font-semibold text-slate-200 text-sm">Extracted JSON Instance</h3>
            </div>
            
            {result && (
              <button
                onClick={copyJson}
                className="flex items-center gap-1.5 px-2.5 py-1 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 rounded text-[11px] font-semibold transition"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                {copied ? "Copied" : "Copy JSON"}
              </button>
            )}
          </div>

          <div className="flex-1 bg-slate-950/40 border border-slate-800/60 rounded-xl p-4 overflow-y-auto font-mono text-[11px] sm:text-xs text-indigo-300 max-h-[400px]">
            {isLoading ? (
              <div className="flex flex-col items-center justify-center h-full space-y-3">
                <RefreshCw className="w-6 h-6 text-indigo-400 animate-spin" />
                <p className="text-slate-400 text-xs animate-pulse">Instructing Gemini to parse responseSchema...</p>
              </div>
            ) : result ? (
              <pre className="whitespace-pre-wrap">{JSON.stringify(result, null, 2)}</pre>
            ) : error ? (
              <div className="flex items-start gap-2.5 text-amber-400 bg-amber-500/5 p-3 rounded-lg border border-amber-500/10 font-sans">
                <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
                <p className="text-xs">{error}</p>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-full text-center space-y-2 py-10 font-sans">
                <FileJson className="w-10 h-10 text-slate-700" />
                <div>
                  <h4 className="font-semibold text-slate-400 text-xs sm:text-sm">No Schema Extracted</h4>
                  <p className="text-[11px] text-slate-500 mt-1 max-w-[250px] mx-auto">
                    Select a preset or edit raw text, then execute Extract Typed JSON Schema.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="mt-4 pt-4 border-t border-slate-800/60 flex items-center gap-2 text-[10px] sm:text-xs text-slate-400 bg-slate-950/20 p-2.5 rounded-lg border border-slate-800/40">
          <Shield className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
          <span>Uses Gemini's native <code className="text-indigo-300">responseSchema</code> parameters for deterministic, structured object output.</span>
        </div>
      </div>
    </div>
  );
}
