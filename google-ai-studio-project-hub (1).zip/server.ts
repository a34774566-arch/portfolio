import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

// Body parsing with higher limits for base64 image uploads
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true, limit: "10mb" }));

let aiInstance: GoogleGenAI | null = null;

function getGeminiClient() {
  if (!aiInstance) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
      throw new Error("GEMINI_API_KEY environment variable is missing. Please add it via Settings > Secrets.");
    }
    aiInstance = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiInstance;
}

// Check key status and server health
app.get("/api/status", (req, res) => {
  const apiKey = process.env.GEMINI_API_KEY;
  const isConfigured = !!apiKey && apiKey !== "MY_GEMINI_API_KEY";
  res.json({
    status: "ok",
    apiKeyConfigured: isConfigured,
    appUrl: process.env.APP_URL || "http://localhost:3000",
  });
});

// Chat session route
app.post("/api/chat", async (req, res) => {
  try {
    const { messages, systemInstruction } = req.body;
    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ error: "Messages array is required" });
    }

    const ai = getGeminiClient();
    
    // Map client messages format to Gemini format
    // Gemini roles must be "user" or "model"
    const contents = messages.map((m: any) => ({
      role: m.role === "assistant" ? "model" : "user",
      parts: [{ text: m.content }],
    }));

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents,
      config: {
        systemInstruction: systemInstruction || "You are a helpful and knowledgeable AI assistant.",
      },
    });

    res.json({ text: response.text });
  } catch (error: any) {
    console.error("Chat error:", error);
    res.status(500).json({ error: error.message || "An error occurred with Gemini API" });
  }
});

// Image description route
app.post("/api/describe-image", async (req, res) => {
  try {
    const { image, prompt } = req.body;
    if (!image) {
      return res.status(400).json({ error: "Image base64 data is required" });
    }

    const ai = getGeminiClient();

    // extract base64 data and mime type
    const match = image.match(/^data:(image\/[a-zA-Z]+);base64,(.+)$/);
    if (!match) {
      return res.status(400).json({ error: "Invalid image format. Must be a base64 data URL." });
    }

    const mimeType = match[1];
    const base64Data = match[2];

    const imagePart = {
      inlineData: {
        mimeType,
        data: base64Data,
      },
    };

    const textPart = {
      text: prompt || "Describe this image in detail and identify any prominent objects, colors, or themes.",
    };

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: { parts: [imagePart, textPart] },
    });

    res.json({ text: response.text });
  } catch (error: any) {
    console.error("Describe image error:", error);
    res.status(500).json({ error: error.message || "An error occurred with Gemini API" });
  }
});

// Structured JSON extraction route
app.post("/api/structured-json", async (req, res) => {
  try {
    const { rawText, taskType } = req.body;
    if (!rawText) {
      return res.status(400).json({ error: "Raw text content is required" });
    }

    const ai = getGeminiClient();

    let prompt = "";
    let schema: any = {};

    if (taskType === "feedback") {
      prompt = `Analyze the sentiment, key categories, and action items from this feedback: "${rawText}"`;
      schema = {
        type: Type.OBJECT,
        properties: {
          sentiment: {
            type: Type.STRING,
            description: "Sentiment of the text: POSITIVE, NEGATIVE, or NEUTRAL",
          },
          sentimentScore: {
            type: Type.NUMBER,
            description: "A score from 0.0 (extremely negative) to 1.0 (extremely positive)",
          },
          categories: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "Key product or service categories mentioned (e.g. Speed, Pricing, UI, Customer Service)",
          },
          keyTakeaways: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "Short list of key points extracted",
          },
          suggestedActions: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "Concrete recommended next actions for the team",
          },
        },
        required: ["sentiment", "sentimentScore", "categories", "keyTakeaways", "suggestedActions"],
      };
    } else if (taskType === "recipe") {
      prompt = `Extract recipe details from this unstructured culinary text: "${rawText}"`;
      schema = {
        type: Type.OBJECT,
        properties: {
          recipeName: { type: Type.STRING, description: "The name of the recipe" },
          difficulty: { type: Type.STRING, description: "Easy, Medium, or Hard" },
          prepTimeMinutes: { type: Type.INTEGER, description: "Estimated preparation time in minutes" },
          ingredients: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                item: { type: Type.STRING, description: "Name of the ingredient" },
                quantity: { type: Type.STRING, description: "Amount/quantity (e.g., 2 cups, 1 tbsp)" },
              },
              required: ["item", "quantity"],
            },
          },
          steps: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "Numbered step-by-step preparation list",
          },
        },
        required: ["recipeName", "difficulty", "prepTimeMinutes", "ingredients", "steps"],
      };
    } else {
      // General Entity Extraction
      prompt = `Extract key entities, events, dates, and locations from this text: "${rawText}"`;
      schema = {
        type: Type.OBJECT,
        properties: {
          summary: { type: Type.STRING, description: "A high-level summary of the text" },
          entities: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING, description: "Name of person, organization, product, or concept" },
                type: { type: Type.STRING, description: "Category of the entity (PERSON, ORG, PRODUCT, CONCEPT)" },
              },
              required: ["name", "type"],
            },
          },
          datesAndDeadlines: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "Any dates, times, or deadlines mentioned in the text",
          },
        },
        required: ["summary", "entities", "datesAndDeadlines"],
      };
    }

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: schema,
      },
    });

    res.json({ result: JSON.parse(response.text || "{}") });
  } catch (error: any) {
    console.error("Structured JSON error:", error);
    res.status(500).json({ error: error.message || "An error occurred with Gemini API" });
  }
});

// Setup development server or production build static folder serving
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT} in ${process.env.NODE_ENV || "development"} mode`);
  });
}

startServer();
